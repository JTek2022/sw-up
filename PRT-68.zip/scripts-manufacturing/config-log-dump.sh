#!/bin/bash

cd ~/

# Create log_history folder if it doesn't exist
mkdir -p return_log_history

# Remove previous temp log output folder, recreate
rm -rf return_log_temp
mkdir -p return_log_temp

# Navigate to the temp log directory
cd return_log_temp

# Run config and log dump script
noctrix-config-log-dump-parse

# On success, noctrix-config-log-dump-parse will have an
# exit code of 0
if [ $? -eq 0 ]
then
	# If successful, copy the output from the temp
	# to the history folder
	cp -R . ../return_log_history/

	# Open the return_log_temp folder so the user can copy
	# the files out to the necessary location
	xdg-open .
fi

echo ""
echo "Press ENTER to exit..."
read -s
