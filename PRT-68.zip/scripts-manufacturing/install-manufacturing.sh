#!/bin/bash

## Remove update notifier so we dont get update popups
sudo apt remove update-notifier update-notifier-common -y
sudo apt-get purge unattended-upgrades -y

## Install required packages
sudo apt install python3-pip tio -y

## Add $USER to USB permissions
sudo adduser $USER dialout

## Install python packages
cd ~/noctrix-sw-tools/python
mv setup-sw-tools.py setup.py
pip3 install .

## Add relevant paths so we can run from desktop shortcut

# If a backup of the original .bashrc doesn't exist, make one now
BACKUPFILE_RC=~/.bashrc_backup
if [ ! -f "$BACKUPFILE_RC" ]; then
	cp ~/.bashrc ~/.bashrc_backup
fi

# Copy original/backup into .bashrc before modifying
cp ~/.bashrc_backup ~/.bashrc

# tell .bashrc to source .bash_profile for terminal windows
echo "" >> ~/.bashrc
echo "source ~/.bash_profile" >> ~/.bashrc

# If a backup of the original .bash_profile doesn't exist, make one now
BACKUPFILE_PROF=~/.bash_profile_backup
if [ ! -f "$BACKUPFILE_PROF" ]; then
    cp ~/.bash_profile ~/.bash_profile_backup
fi

# Copy original/backup into .profile before modifying
cp ~/.bash_profile_backup ~/.bash_profile

# Add python user install path to system path
echo "" >> ~/.bash_profile
echo "export PATH=\"\$PATH:\$HOME/.local/bin\"" >> ~/.bash_profile

## Create Desktop Shortcut

# Copy desktop file
cp ~/noctrix-sw-tools/scripts-manufacturing/noctrix-fw-config.desktop ~/Desktop/
cp ~/noctrix-sw-tools/scripts-manufacturing/noctrix-config-log-dump.desktop ~/Desktop/

# Make launchable
sudo desktop-file-install --mode=0755 ~/Desktop/noctrix-log-dump.desktop
sudo desktop-file-install --mode=0755 ~/Desktop/noctrix-config-log-dump.desktop

# Make executable
gio set ~/Desktop/noctrix-fw-config.desktop metadata::trusted true
chmod +x ~/Desktop/noctrix-fw-config.desktop

gio set ~/Desktop/noctrix-config-log-dump.desktop metadata::trusted true
chmod +x ~/Desktop/noctrix-config-log-dump.desktop

## We must reboot to finish setup
echo ""
echo "------------------------------------------------------"
echo ""
echo "Initialization setup requires rebooting."
echo "Press ENTER to reboot now..."
read -s
sudo reboot
