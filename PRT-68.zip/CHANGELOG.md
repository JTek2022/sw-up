# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.13.4] - 2023-06-19

### Added

- fw-config: erase datalog logs and add error handling to log erase command.

### Changed

- fw-config: allow only alphanumeric characters for device sn.

## [1.13.3] - 2023-06-15

### Changed

- log_parser: add support for additional boot log lines before the 'boot' message.

## [1.13.2] - 2023-06-09

### Changed

- imu-config: update fw configuration variables and add ct-02 mode.
- fw-config: persist SERID after config clear.

## [1.13.1] - 2023-06-05

### Added

- Remove file headers present in logs from the `log dump` command.
- fw-config: run `config clear` and `log erase` commands at the beginning of the script.
- Add desktop background image to the assets folder.
- Fix erroneous line breaks at the middle of log lines from the `log dump` and `cat` commands.

### Fixed

- upload: fix last upload date not being used as start date when uploading only 1 band.
- analyze: fix leg bands available prompt to only accept 1 or 2.

## [1.13.0] - 2023-05-24

### Added

- Add Dockerfile for building a docker image for the commercial install script.
- Add CONTRIBUTING.md document.
- upload: print list of downloaded log file ids from the device.
- Add `imu-log-test` script to perform quick test of device IMU logging capabilities.
- Set configuration for Production environment.
- fw-config: log the user-entered device sn to the device logs.
- Add user-readable description to InvalidDeviceException.
- upload: add option to skip uploading logs on incorrect user-device mapping.
- Add noctrix logo as icon to "Log Dump & Upload" desktop file.
- upload: warn user if the second band leg id is the same as the first.

### Changed

- Rename commercial install script to "install-commercial".
- imu-dump: skip empty bin file instead of raising an exception.
- imu-dump: start retrieving data by the newest file instead of the oldest.
- fw-config: device SN input needs to be exactly 9 characters.

### Removed

- Remove clinical flavors from release package.
- Remove sham-randomizer and disable-sham scripts. Device can now only be set to active.
- fw-config: remove all changes to config variables except those related to the questions.
- fw-config: remove subject vs calibration kit prompt. M_CALIB now uses the firmware's default value.

### Fixed

- Add missing pip package requirements.
- Fix upload desktop file to use the correct script.
- upload: fix LEGID to only consider 0=left and 1=right.

## [1.12.2] - 2022-12-06

### Added

- Hide password terminal output on upload script.
- Support different datetime iso 8601 variations from Galen.

### Fixed

- Install jre and libreoffice for commercial install.

## [1.12.1] - 2022-11-18

### Fixed

- Add missing package requirements and prevent installing new major versions.
- Create config directory for environments during install if it does not exist.

## [1.12.0] - 2022-11-15

### Added

- Autodetect patient based on serial number during log upload.
- Press enter to default to yes on Y/N prompts.
- Prefill log analysis range for the log upload with last upload date and today's date.
- Add support for fast writes to "noctrix-dfu-recovery", for 20x speedup.
- Add "noctrix-set-levels" desktop app to all flavors.
- New flavor "scripts-commercial" aimed for commercial launch.
- Support different backend environments for development and production.

## [1.11.2] - 2022-10-27

### Added

- New script "noctrix-log-dump-parse-analyze-upload" can be used to upload data to the cloud for the log dump & analysis.

## [1.11.1] - 2022-10-26

## Added

- New script "noctrix-dfu-recovery" can be used to send a firmware update via the normal serial console, instead of requiring mcumgr. This can be used to update any firmware version and is specifically useful for 0.14.4 and 0.14.5 firmware devices that have a stack overflow bug in the mcumgr implementation. To use just connect a board and run `noctrix-dfu-recovery app-xxx.bin`.

### Fixed

- Increase timeout for filesystem commands. "fs statvfs /imu/" takes about 50 seconds with full IMU flash. The timeout defaults to 20s and we bump it to 90s for these calls.

## [1.11.0] - 2022-10-18

### Added

- Initial release.
