''' Setuptools script '''
from setuptools import setup

# Normally many folks don't advise loading requirements from here
# However this is a simple project, with simple requirements,
# And this will help keep requirements in one place.
reqs = []
with open('requirements.txt', 'r') as fil:
    for line in fil.readlines():
        reqs.append(line.strip())

setup(name='noctrix-sw-tools',
      version='1.13.4',
      description='Python libraries for managing Noctrix devices',
      author='Matthew Winters',
      author_email='matt@noctrixhealth.com',
      packages=['noctrix'],
      scripts=['bin/noctrix-tool',
               'bin/noctrix-calib-set',
               'bin/noctrix-log-parse',
               'bin/noctrix-dump-and-parse',
               'bin/noctrix-set-levels',
               'bin/noctrix-erase-imu-files',
               'bin/noctrix-fw-config',
               'bin/noctrix-get-remaining-storage',
               'bin/noctrix-imu-config',
               'bin/noctrix-imu-dump-multi',
               'bin/noctrix-imu-log-start',
               'bin/noctrix-imu-log-stop',
               'bin/noctrix-imu-log-test',
               'bin/noctrix-set-active',
               'bin/noctrix-log-analysis',
               'bin/noctrix-config-log-dump-parse',
               'bin/noctrix-log-dump-parse-analyze',
               'bin/noctrix-log-dump-parse-analyze-upload',
               'bin/noctrix-dfu-recovery',
               ],
      install_requires=reqs,
      zip_safe=False)
