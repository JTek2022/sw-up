import json
import os


def _get_config_path():
    return os.path.join(
        os.environ.get('XDG_CONFIG_HOME') or
        os.environ.get('APPDATA') or
        os.path.join(os.environ['HOME'], '.config'),
        "noctrix"
    )


class GalenEnvironment(object):
    def __init__(self, file_path=f"{_get_config_path()}/environment.json"):
        self.config = self._read_json_file(file_path)

    def _read_json_file(self, file_path: str):
        with open(file_path, "r") as f:
            return json.load(f)

    @property
    def tenant_domain(self):
        return self.config["galen"]["tenant_domain"]

    @property
    def device_id(self):
        return self.config["galen"]["device_id"]

    @property
    def device_data_model_id_raw_log(self):
        return self.config["galen"]["device_data_model_ids"]["raw_log"]

    @property
    def device_data_model_id_log_dump(self):
        return self.config["galen"]["device_data_model_ids"]["log_dump"]

    @property
    def device_property_set_id_raw_log(self):
        return self.config["galen"]["device_property_set_ids"]["raw_log"]

    @property
    def device_property_set_id_log_dump(self):
        return self.config["galen"]["device_property_set_ids"]["log_dump"]
