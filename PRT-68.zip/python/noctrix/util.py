import time

# Function decorator that causes the function to automatically retry
# if it raises the given exception.  A message is optionally printed
# on failure.  After max_tries attempts, the exception is passed
# through.
def retry_if_raised(exc, message=None, max_tries=5, delay=1, silent=False):
    def f1(func):
        def f2(*args, **kwargs):
            for n in range(max_tries):
                try:
                    return func(*args, **kwargs)
                except exc:
                    if message:
                        print(f"{message} ({n+1})\n\n")
                    if n == max_tries - 1:
                        if not silent:
                            print(f"Max number of retries ({max_tries}) exceeded")
                        raise
                    time.sleep(delay)
        return f2
    return f1
