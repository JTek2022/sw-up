#!/usr/bin/env python

# Firmware Configurations for IMU

# IMU configured to run for 30 minutes after therapy stops (standard 30 min ther session)
CFG_IMU_30 = {
    "M_CALIB": 0,           # Therapy mode
    "T_BT_ADV": 30000,      # Time to advertise button press (consistent throughout CT-02)
    "B_MIN1": 3675,         # Minimum batttery voltage to start a session (consistent throughout CT-02)
    "B_MIN2": 3250,         # End therapy collection if battery voltage < B_MIN2 (consistent throughout CT-02)
    "MTN_LOG": 1,           # Record accel/IMU data during therapy
    "MTN_MATCH": 0,         # Don't set motion logging duration equal to therapy
    "MTN_ALTLOG": 0,        # Record IMU with every therapy session (don't alternate)
    "M_PB": 0,              # Turn personalized battery extension off
    "T_MTN_LOG": 3600000,   # Record IMU for 60 min total
    "T_MTN_MIN": 0          # Continue to record IMU regardless of the duration of therapy run
}

# IMU configured to run for 60 minutes after therapy stops (standard 30 min ther session)
CFG_IMU_60 = {
    "M_CALIB": 0,           # Therapy mode
    "T_BT_ADV": 30000,      # Time to advertise button press (consistent throughout CT-02)
    "B_MIN1": 3675,         # Minimum batttery voltage to start a session (consistent throughout CT-02)
    "B_MIN2": 3250,         # End therapy collection if battery voltage < B_MIN2 (consistent throughout CT-02)
    "MTN_LOG": 1,           # Record accel/IMU data during therapy
    "MTN_MATCH": 0,         # Don't set motion logging duration equal to therapy
    "MTN_ALTLOG": 0,        # Record IMU with every therapy session (don't alternate)
    "M_PB": 0,              # Turn personalized battery extension off
    "T_MTN_LOG": 5400000,   # Record IMU for 90 min total
    "T_MTN_MIN": 0          # Continue to record IMU regardless of the duration of therapy run
}
# Disable motion logging triggered by therapy stops/starts. Manual control ("datalog_start") only
CFG_IMU_MANUAL = {
    "M_CALIB": 0,           # Therapy mode
    "T_BT_ADV": 30000,      # Time to advertise button press (consistent throughout CT-02)
    "B_MIN1": 3675,         # Minimum batttery voltage to start a session (consistent throughout CT-02)
    "B_MIN2": 3250,         # End therapy collection if battery voltage < B_MIN2 (consistent throughout CT-02)
    "MTN_LOG": 0,           # Don't record accel/IMU data during therapy, don't stop it with therapy either
    "MTN_MATCH": 0,         # Don't set motion logging duration equal to therapy
    "MTN_ALTLOG": 0,        # Record IMU with every therapy session (don't alternate)
    "M_PB": 0,              # Turn personalized battery extension off
    "T_MTN_MIN": 0          # Continue to record IMU regardless of the duration of therapy run
}

CFG_SUBJECT_CT02 = {        #CT-02 Specific Default Config Settings
    "M_CALIB": 0,           # Therapy mode
    "T_BT_ADV": 30000,      # Time to advertise button press (consistent throughout CT-02)
    "B_MIN1": 3675,         # Minimum batttery voltage to start a session (consistent throughout CT-02)
    "B_MIN2": 3250,         # End therapy collection if battery voltage < B_MIN2 (consistent throughout CT-02)
    "MTN_LOG": 0,           # Record accel/IMU data during therapy
    "MTN_MATCH": 0,         # Don't set motion logging duration equal to therapy
    "MTN_ALTLOG": 0,        # Record IMU with every therapy session (don't alternate)
    "M_PB": 0,              # Turn personalized battery extension off
    "L1": 0,                # Set all therapy levels to 0 (change to user settings if needed after)
    "L2": 0,
    "L3": 0,
    "L4": 0,
    "L5": 0,
    "T_MTN_LOG": 5400000,   # Record IMU for 90 min total (SIT)
    "T_MTN_MIN": 0          # Continue to record IMU regardless of the duration of therapy run
}