import os
from datetime import datetime

import dateutil.parser
import requests

try:
    from galen_environment import *
except ModuleNotFoundError:
    from noctrix.galen_environment import *


def _datetime_utc_to_galen_format(dt: datetime) -> str:
    # Return in yyyy-MM-dd'T'HH:mm:ss.SSS'Z' ISO 8601 format
    # https://galendata.atlassian.net/wiki/spaces/GCS/pages/1471676420/API+Integration+Guide+V3?parentProduct=JSM-Portal&parentProductContentContainerId=10004&initialAllowedFeatures=&locale=en-US#Data-Validation
    # ie: "2022-05-03T21:08:05.000Z" (or alternatively 2022-11-25T17:55:42.487+00:00)
    return dt.isoformat(timespec='milliseconds') + "Z"


def _datetime_from_galen_format(dt_str: str) -> datetime:
    # Return from ISO 8601 format (and unexpected variations)
    return dateutil.parser.isoparse(dt_str)


class GalenUser(object):
    """
    Galen User model class.
    """

    def __init__(self, id: str, first_name: str, last_name: str, email: str, tenant=None, practice=None):
        self.id = id
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.tenant = tenant
        self.practice = practice

    def __str__(self):
        return f'User(id={self.id}, first_name={self.first_name}, last_name={self.last_name}, email={self.email})'


class GalenApiConfig(object):
    """
    Configuration class for defining the the environment variables and
    requirements to interact with the Galen API
    """

    def __init__(self, base_url: str = "https://api.galencloud.com", environment: GalenEnvironment = None):
        self.base_url = base_url
        if environment is None:
            environment = GalenEnvironment()
        # Devices (see the whole list at https://noctrixdev.galencloud.com/device/list)
        self.device_id = environment.device_id
        # Data Models (see the whole list at https://noctrixdev.galencloud.com/device/edit/55db47d1-3949-4658-9530-062dab694b24)
        self.raw_logs_device_data_model_id = environment.device_data_model_id_raw_log
        self.raw_logs_device_property_set_id = environment.device_property_set_id_raw_log
        self.log_dump_device_data_model_id = environment.device_data_model_id_log_dump
        self.log_dump_device_property_set_id = environment.device_property_set_id_log_dump
        # Default headers
        x_tenant_domain = environment.tenant_domain
        x_api_version = "3"
        x_app_type = "Device"
        self.base_api_headers = {
            "x-tenant-domain": "%s" % (x_tenant_domain),
            "x-api-version": "%s" % (x_api_version),
            "x-app-type": "%s" % (x_app_type)
        }

    def auth_headers(self, bearer_token):
        headers = self.base_api_headers
        headers["Authorization"] = bearer_token
        return headers


class GalenApiService(object):
    """
    Service class for interacting with the Galen Cloud API.
    """

    def __init__(self, config: GalenApiConfig):
        self.config = config

    # region Authentication
    def login(self, email: str, password: str):
        """
        Authenticates the user via email and password
        and applies the bearer token to the headers
        for subsequent requests.
        """
        response = requests.post(
            self.config.base_url + "/auth/login",
            headers=self.config.base_api_headers,
            data={"emailAddress": email, "password": password}
        )
        # print(curlify.to_curl(response.request))
        if response.ok:
            bearer_token = response.headers["Authorization"]
            self.bearer_token = bearer_token
        else:
            raise Exception(
                f"Error logging in, please verify your credentials. Error: {response.text}")
    # endregion

    # region Device Instance Management
    def get_device_instance_association(self, serial_number: str):
        """
        Gets the Device Instance for a given serial number.
        Returns a tuple (device_instance_id, galen_patient)
        """
        response = requests.get(
            self.config.base_url + "/device/instance/currentlink",
            headers=self.config.auth_headers(self.bearer_token),
            params={
                "deviceId": self.config.device_id,
                "identifier": serial_number}
        )
        if response.ok:
            content_list = response.json()["content"]
            if content_list is None or len(content_list) == 0:
                return (None, None)
            device_instance_id = content_list[0].get("deviceInstanceId")
            current_association = content_list[0].get("currentAssociation")
            if current_association is None:
                return (device_instance_id, None)
            else:
                user_json = current_association["owner"]
                user = GalenUser(user_json["userId"], user_json["firstName"],
                                 user_json["lastName"], user_json["emailAddress"])
                return (device_instance_id, user)
        elif response.status_code == 404:
            return (None, None)
        else:
            raise Exception(
                f"Error getting device instance association. Error: {response.text}")

    def create_device_instance(self, serial_number: str, firmware_version: str) -> str:
        """
        Creates a device instance for a device.
        Returns the new device instance id.
        """
        response = requests.post(
            self.config.base_url + "/device/instance",
            headers=self.config.auth_headers(self.bearer_token),
            json={
                "identifier": serial_number,
                "device": {"deviceId": self.config.device_id},
                "firmwareVersion": firmware_version
            }
        )
        if response.ok:
            return response.json()["deviceInstanceId"]
        else:
            raise Exception(
                f"Error creating device instance. Error: {response.text}")

    # TODO: Check with Galen, this endpoint is not working (returns 200 but is not updating the firmwareVersion)
    def update_device_instance(self, device_instance_id: str, serial_number: str, firmware_version: str):
        """
        Updates the given devince instance.
        Returns the updated device instance id.
        """
        response = requests.put(
            self.config.base_url + "/device/instance",
            headers=self.config.auth_headers(self.bearer_token),
            json={
                "identifier": serial_number,
                "deviceInstanceId": device_instance_id,
                "device": {"deviceId": self.config.device_id},
                "firmwareVersion": firmware_version
            }
        )
        # print(curlify.to_curl(response.request))
        if response.ok:
            return
        else:
            raise Exception(
                f"Error updating device instance. Error: {response.text}")
    # endregion

    # region User Management
    def get_current_user(self) -> GalenUser:
        """
        Returns the current logged in user.
        """
        response = requests.get(
            self.config.base_url + "/user/me",
            headers=self.config.auth_headers(self.bearer_token)
        )
        if response.ok:
            user_json = response.json()
            user = GalenUser(user_json["userId"], user_json["firstName"],
                             user_json["lastName"], user_json["emailAddress"],
                             user_json["tenant"], user_json["currentRole"]["practice"])
            return user
        else:
            raise Exception(
                f"Error getting current user. Error: {response.text}")

    def search_patient(self, first_name: str, last_name: str, date_of_birth: datetime) -> GalenUser:
        """
        Gets the first patient that meets the provided filtering criteria.
        Returns a GalenUser or None.
        """
        response = requests.get(
            self.config.base_url + "/user/user",
            headers=self.config.auth_headers(self.bearer_token),
            params={
                "nameLike": f"{first_name} {last_name}",
                "dateOfBirth": date_of_birth.strftime("%Y-%m-%d"),
                "role": "Patient"
            }
        )
        if response.ok:
            content_list = response.json()["content"]
            if content_list is None or len(content_list) == 0:
                return None
            else:
                user_json = content_list
                if len(user_json) > 0:
                    # Warn if there was more than 1 patient with the same parameters
                    # TODO: Unlinkely to happen, but return a list of patients with a picker to choose from
                    if len(user_json) > 1:
                        def display_user(json):
                            return f"{json['firstName']} {json['lastName']}"
                        print(
                            f"\nWARNING: Multiple users found for patient {first_name} {last_name}: {list(map(display_user, user_json))}. Please contact your administrator with this information.")
                    user_json = user_json[0]
                    user = GalenUser(user_json["userId"], user_json["firstName"],
                                     user_json["lastName"], user_json["emailAddress"])
                    return user
                else:
                    return None
        else:
            return None

    def create_patient(self, first_name: str, last_name: str, email: str, date_of_birth: datetime, tenant, practice) -> GalenUser:
        """
        Creates a patient.
        Returns the new GalenUser or raises an Exception.
        """
        response = requests.post(
            self.config.base_url + "/user/user",
            headers=self.config.auth_headers(self.bearer_token),
            json={
                "user": {
                    "firstName": first_name,
                    "lastName": last_name,
                    "emailAddress": email,
                    "dateOfBirth": date_of_birth.strftime("%Y-%m-%d"),
                    "roles": [{
                        "role": "Patient",
                        "practice": practice,
                    }],
                    "loggableAccount": False,
                    "tenant": tenant,
                }
            }
        )

        if response.ok:
            return self.search_patient(first_name, last_name, date_of_birth)
        else:
            raise Exception(
                f"Error creating new patient. Error: {response.text}")
    # endregion

    # region Device Data Management

    def get_uploaded_logs(self, serial_number: str):
        """
        Gets current raw logs uploaded for a given user.
        Returns the user, last upload date, and a list of log ids sorted ASC 
        (GalenUser?, DateTime?, [int]?)
        """
        response = requests.post(
            self.config.base_url + "/data/devicedata-advanced/owner",
            headers=self.config.auth_headers(self.bearer_token),
            params={
                # TODO: 10,000 records is more than enough, but should re-visit this to deal with pagination differently
                "pageSize": 10000,
            },
            json={
                "deviceDataModelId": self.config.raw_logs_device_data_model_id,
                "deviceCriteria": [{
                    "key": "SerialNumber",
                    "value": serial_number,
                    "operator": "Equal",
                }],
            }
        )
        if response.ok:
            content = response.json()["content"]
            # Group by user
            user_content = {}
            for entry in content:
                ownerId = entry["ownerId"]
                if user_content.get(ownerId):
                    user_content[ownerId].append(entry)
                else:
                    user_content[ownerId] = [entry]
            if len(user_content) == 0:
                return (None, [])
            if len(user_content) > 1:
                print(
                    f"\nWARNING: Multiple users found for serial number {serial_number}: {list(user_content.keys())}. Please contact your administrator with this information.")
            user_content = list(user_content.values())[0]
            # Get the patient
            owner = user_content[0]["owner"]
            user = GalenUser(owner["userId"], owner["firstName"],
                             owner["lastName"], owner["emailAddress"])
            upload_dates = list(map(
                lambda x:  _datetime_from_galen_format(x["data"]["UpdatedAt"]["value"]) if x.get(
                    "data") and x.get("data").get("UpdatedAt") and x.get("data").get("UpdatedAt").get("value") else None,
                user_content
            ))
            upload_dates = list(filter(lambda x: x is not None, upload_dates))
            last_upload_date = max(upload_dates) if len(
                upload_dates) > 0 else None
            file_ids_lists = list(map(
                lambda x: x["data"]["FileIds"]["value"] if x.get(
                    "data") and x.get("data").get("FileIds") and x.get("data").get("FileIds").get("value") else [],
                user_content
            ))
            if len(file_ids_lists) == 0:
                return (user, last_upload_date, [])
            # Sort file ids
            file_ids = [item for sublist in file_ids_lists for item in sublist]
            file_ids.sort()
            return (user, last_upload_date, file_ids)
        elif response.status_code == 404:
            return (None, None, [])
        else:
            raise Exception(
                f"Error getting previously uploaded logs. Error: {response.text}")

    def upload_log_dump(self, owner_id: str, left_leg_raw_fn, right_leg_raw_fn, left_leg_parsed_fn, right_leg_parsed_fn, analysis_fn):
        """
        Uploads generated files to Galen's "Log Dump & Analysis" model.
        """
        response = requests.post(
            self.config.base_url + "/data/devicedata",
            headers=self.config.auth_headers(self.bearer_token),
            json={
                "deviceDataModelId": self.config.log_dump_device_data_model_id,
                "devicePropertySetId": self.config.log_dump_device_property_set_id,
                "ownerId": owner_id,
                "data": {
                    "UploadDate": _datetime_utc_to_galen_format(datetime.utcnow()),
                }
            }
        )
        # print(curlify.to_curl(response.request))
        if not response.ok:
            raise Exception(
                f"Error uploading log dump. Error: {response.text}")
        else:
            device_data_id = response.text

        # Upload files, does not raise exception on failure
        if left_leg_raw_fn:
            self.__upload_file_to_record(
                self.config.log_dump_device_data_model_id, device_data_id, "RawFileLeftLeg", left_leg_raw_fn)
        if right_leg_raw_fn:
            self.__upload_file_to_record(
                self.config.log_dump_device_data_model_id, device_data_id, "RawFileRightLeg", right_leg_raw_fn)
        if left_leg_parsed_fn:
            self.__upload_file_to_record(
                self.config.log_dump_device_data_model_id, device_data_id, "ParsedFileLeftLeg", left_leg_parsed_fn)
        if right_leg_parsed_fn:
            self.__upload_file_to_record(
                self.config.log_dump_device_data_model_id, device_data_id, "ParsedFileRightLeg", right_leg_parsed_fn)
        if analysis_fn:
            self.__upload_file_to_record(
                self.config.log_dump_device_data_model_id, device_data_id, "AnalysisFile", analysis_fn)

    def upload_raw_file(self, owner_id: str, serial_number: str, leg_id: int, file_ids, file_fn):
        """
        Uploads device logs to "Log File Raw" model.
        """
        request_data = {
            "SerialNumber": serial_number,
            "FileIds": file_ids,
            "LegId": leg_id,
            "IsFileReady": False,
            "IsFileParsed": False,
            "UpdatedAt": _datetime_utc_to_galen_format(datetime.utcnow()),
        }
        response = requests.post(
            self.config.base_url + "/data/devicedata",
            headers=self.config.auth_headers(self.bearer_token),
            json={
                "deviceDataModelId": self.config.raw_logs_device_data_model_id,
                "devicePropertySetId": self.config.raw_logs_device_property_set_id,
                "ownerId": owner_id,
                "data": request_data
            }
        )
        # print(curlify.to_curl(response.request))
        if not response.ok:
            raise Exception(
                f"Error uploading raw file. Error: {response.text}")
        else:
            device_data_id = response.text

        # Upload Raw File
        self.__upload_file_to_record(
            self.config.raw_logs_device_data_model_id, device_data_id, "VerboseFile", file_fn)
        # Mark as ready
        request_data["IsFileReady"] = True
        response = requests.post(
            self.config.base_url + "/data/devicedata",
            headers=self.config.auth_headers(self.bearer_token),
            json={
                "deviceDataModelId": self.config.raw_logs_device_data_model_id,
                "devicePropertySetId": self.config.raw_logs_device_property_set_id,
                "deviceDataId": device_data_id,
                "ownerId": owner_id,
                "data": request_data
            }
        )
        if not response.ok:
            raise Exception(
                f"Error marking raw file as ready. Error: {response.text}")

    def __upload_file_to_record(self, device_data_model_id: str, device_data_id: str, property_code: str, file_path: str):
        """
        Uploads a file to a device data record.
        Prints a warning if the upload fails.
        """
        response = requests.post(
            self.config.base_url + f"/data/devicedata/{device_data_id}",
            headers=self.config.auth_headers(self.bearer_token),
            data={
                "deviceDataModelId": device_data_model_id,
                "propertyCode": property_code,
            },
            files={
                "data": (os.path.basename(file_path), open(file_path, 'rb')),
            },
        )
        if not response.ok:
            print(
                f"WARNING: Log file {property_code} was NOT uploaded. Error: {response.text}")

    # endregion
