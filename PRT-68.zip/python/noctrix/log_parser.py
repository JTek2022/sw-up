import re
from math import ceil
from datetime import datetime, timedelta

SECONDS_IN_MINUTE = 60
SECONDS_IN_HOUR = SECONDS_IN_MINUTE * 60
SECONDS_IN_DAY = SECONDS_IN_HOUR * 24

SESSION_COLUMN_HEADERS = [
    "#",
    "DQ Date",
    "Stim time",
    "Stim dur.",
    "Stop early",
    "Days used",
    "Gap",
    "Stim date",
    "Stim time",
    "LVL",
    "V-5",
]

IMU_COLUMN_HEADERS = [
    "Filename",
    "Start",
    "End"
]


def round_up(n, decimals=0):
    multiplier = 10 ** decimals
    return ceil(n * multiplier) / multiplier


class Level(object):
    """Container class for a stimulation level to be used by StimLevels class"""

    def __init__(self, name):
        self._name = name
        self._value = 0
        self._is_set = False

    @property
    def name(self):
        return self._name

    @property
    def is_set(self):
        return self._is_set

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, val):
        self._value = val
        self._is_set = True

    def __str__(self):
        return f"Level {self.name}: {self.value}mA"


class StimLevels(object):
    """Container class of multiple Levels objects to make tracking/recording/recalling
    stimulation levels used during therapy easier when this information is later
    recorded in a stim session object
    """

    def __init__(self):
        self.L1 = Level("L1")
        self.L2 = Level("L2")
        self.L3 = Level("L3")
        self.L4 = Level("L4")
        self.L5 = Level("L5")
        self._levels = [self.L1, self.L2, self.L3, self.L4, self.L5]
        self._latest_level = Level("N/A")
        self._latest_value = 99

    def set_level(self, level, val):
        self._levels[level - 1].value = val

    def get_level(self, level):
        return self._levels[level - 1]

    def set_latest_level_by_val(self, val):
        self._latest_value = val
        level_found = False
        for level in self._levels:
            if val == level.value:
                level_found = True
                self._latest_level = level
                # print(f"Latest level set to {val}mA")

        if self.has_all_levels() and not level_found:
            raise ValueError(f"No corresponding level for {val}mA found")

    @property
    def latest_level(self):
        return self._latest_level

    @property
    def latest_value(self):
        return self._latest_value

    def has_all_levels(self):
        has_levels = True
        for level in self._levels:
            if not level.is_set:
                has_levels = False
                break
        return has_levels


class StimEvent(object):
    """Container class for stimulation events. Provides a simplified
    property for calculating duration in minutes once datetimes have
    been applied
    """

    def __init__(self):
        self.ts_start = 0
        self.ts_end = 0
        self.dt_start = None
        self.dt_end = None
        self.end_reason = None
        self.error_type = None
        self.stim_levels = StimLevels()
        self.v5 = "-"

    @property
    def duration_in_min(self):
        return int(round((self.dt_end - self.dt_start).total_seconds() / 60, 0))

    @property
    def latest_level(self):
        if self.stim_levels.has_all_levels():
            return self.stim_levels.latest_level.name
        else:
            return str(self.stim_levels.latest_value)

    def __str__(self):
        return f"{self.dt_start} ({self.ts_start}) | {self.dt_end} ({self.ts_end}) | {self.end_reason} | {self.error_type}"


class StimSession(object):
    """Container class for stimulation sessions. Used to store session data
    and provide an easy method to convert that to a csv format for file output
    """

    def __init__(self):
        self.session_num = 0
        self.dq_date = None
        self.stim_start_time = 0
        self.stim_duration = 0
        self.days_used = 0
        self.early_stop_reason = "-"
        self.gap_1_10th_days = "-"
        self.stim_date = None
        self.latest_level = "-"
        self.v5 = "-"

    def csvify(self):
        return str(self).replace(" | ", ",")

    def __str__(self):
        s = f"{self.session_num} | {self.dq_date} | {self.stim_start_time} | {self.stim_duration} | {self.early_stop_reason} | "
        s += f"{self.days_used} | {self.gap_1_10th_days} | {self.stim_date} | {self.stim_start_time} | {self.latest_level} | {self.v5}"
        return s

class IMUFile(object):
    """Container class for IMU files. Used to store filename, start timestamp, end timestamp"""

    def __init__(self):
        self.filename = ""
        self.ts_start = 0
        self.ts_end   = 0
        self.dt_start = None
        self.dt_end = None

    def csvify(self):
        return str(self).replace(" | ", ",")

    def __str__(self):
        s = f"{self.filename} | {self.dt_start} | {self.dt_end}"
        return s

class LogEntry(object):
    """Container class for log entries. Automatically converts hex timestamp
    to seconds/milliseconds
    """

    def __init__(self, timestamp, msg):
        self.ts_ms = int(timestamp, 16) * 10
        self.ts_s = self.ts_ms // 1000
        self.ts_s_initial = self.ts_s
        self.dt = None
        self.msg = msg

    def __str__(self):
        return f"{self.ts_s} | {self.msg}"


class LogFile(object):
    """Log file class that takes in a series of logfile paths, opens them,
    corrects for hard resets/reboots, normalizes timestamps to a known
    timestamp message (the MOST RECENT ONE, i.e. the first "time is" message
    in the LAST file indicated by infile_paths), then finds stimulation events
    and creates an array of these stimulation events (see StimEvent)
    """

    def __init__(self, infile_paths=[], find_evts=True, find_imu=False):
        self.infile_paths = infile_paths
        self.raw_content = []
        self.log_entries = []
        self.stim_events = []
        self.imu_files   = []
        self.intake_files()
        self.adjust_boot_timestamps()
        self.normalize_timestamps()
        if find_evts:
            self.find_events()
        if find_imu:
            self.find_imu_files()

    def intake_files(self):
        self.raw_content = []
        # Read in raw logfile(s)
        for fn in self.infile_paths:
            with open(fn, "r+") as f:
                self.raw_content += f.readlines()

        # Pull out all the log lines
        for line in self.raw_content:
            stripped_line = line.rstrip("\r\n")
            m = re.search("^([0-9a-f]{8})[|](.*)$", stripped_line)
            if not m:
                # print("skipping line %d" % linenum)
                continue
            try:
                (ts, msg) = stripped_line.split("|")
            except ValueError as e:
                print(f"Found an erroneous log line, skipping: {stripped_line}")
                continue

            self.log_entries.append(LogEntry(ts, msg))

    def adjust_boot_timestamps(self):
        # The clock resets to 0 when the device boots.
        # A log entry with a "boot" message indicates a new boot.
        # Adjust timestamps to account for this to form a continuous timeline.
        # NOTE: The "boot" message may NOT be the first message after boot.
        boot_found = False
        last_ts_before_boot = 0
        for i, entry in enumerate(self.log_entries):
            if (i > 0) and ("boot" in entry.msg):
                # Find the highest value timestamp before the boot
                last_idx_before_boot = 0
                for j in reversed(range(i)):
                    if self.log_entries[j].ts_s_initial > entry.ts_s_initial:
                        last_ts_before_boot = self.log_entries[j].ts_s
                        last_idx_before_boot = j
                        break
                # Fix timestamps between the shutdown and the boot (if any)
                if last_idx_before_boot + 1 < i:
                    for k in range(last_idx_before_boot+1, i):
                        self.log_entries[k].ts_s = self.log_entries[k].ts_s_initial + last_ts_before_boot
                boot_found = True
            # If we've found a boot message, adjust all timestamps to account for the clock reset
            if boot_found:
                entry.ts_s += last_ts_before_boot

    def normalize_timestamps(self):
        date_found = False
        time_found = False
        ts_idx = 0
        datetime_str = ""
        datetime_key_entry = None

        # Start at the end of the log entries so we can find the MOST RECENT timestamp
        for idx, entry in reversed(list(enumerate(self.log_entries))):
            msg = entry.msg.lower()
            date_idx = msg.find("date is ")
            time_idx = msg.find("time is ")

            if time_idx != -1:
                time_found = True
                ts_idx = idx
                datetime_str = entry.msg.lower()
                datetime_key_entry = entry
                if date_idx != -1:
                    date_found = True
                break

        if not time_found:
            raise Exception("No known timestamp found, exiting...")

        # Attempt to parse datetime string or timestamp
        try:
            if date_found and time_found:
                # date and time format, i.e. user msg: date is 09-23-2020 and time is 16:52
                date_str = datetime_str.split("date is ")[1][:10]
                time_str = datetime_str.split("time is ")[1][:5]
                datetime_key_entry.dt = datetime.strptime(
                    f"{date_str} {time_str}", "%m-%d-%Y %H:%M"
                )
            else:
                # timestamp format: i.e. Time is 12345678
                numeric_timestamp = int(datetime_str.split("time is")[1])
                datetime_key_entry.dt = datetime.fromtimestamp(numeric_timestamp)
        except Exception as e:
            raise Exception(
                f'Error parsing timestamp string ("{datetime_str}"): {e.message}'
            )

        # Add a modified datetime based off time between key timestamp and other events in log
        for entry in self.log_entries:
            delta = timedelta(seconds=datetime_key_entry.ts_s - entry.ts_s)
            entry.dt = datetime_key_entry.dt - delta
            # print(f"{entry.dt} {entry.msg}")

    def find_imu_files(self):
        current_file = IMUFile()

        for idx, entry in enumerate(self.log_entries):
            msg = entry.msg

            if current_file.ts_start == 0:
                # Looking for start of IMU file
                if "Datalog: begin writing" in msg:
                    current_file.ts_start = entry.ts_s
                    current_file.dt_start = entry.dt
                    current_file.filename = (msg.split("/"))[-1]
            else:
                # Looking for end timestamp
                if "Datalog: Stopping" in msg:
                    current_file.ts_end = entry.ts_s
                    current_file.dt_end = entry.dt
                    self.imu_files.append(current_file)
                    current_file = IMUFile()

    def find_events(self):
        current_event = StimEvent()
        is_calib = True
        event_complete = False
        v5_reading_found = False

        for idx, entry in enumerate(self.log_entries):
            msg = entry.msg

            if current_event.ts_start == 0:
                # Looking for a start event
                if "MainFSM new state: On" in msg:
                    current_event.ts_start = entry.ts_s
                    current_event.dt_start = entry.dt
            else:
                # Looking for an end event and level information

                # Because default device config is calibration mode, if the M_CALIB
                # value was never set then it won't appear in the logs on therapy start.
                # Assume calibration mode by the time we reach "Waveform init" if we
                # havent seen M_CALIB set to 0.

                # Check first if M_CALIB is set to 0. If so, this is NOT a calibration event
                if "config M_CALIB" in msg:
                    calib_val = int(
                        msg[len("config M_CALIB ") : len("config M_CALIB ") + 8], 16
                    )
                    if calib_val == 0:
                        is_calib = False

                # Check for "Waveform init". Create a new event if this is a calib session
                if "Waveform init" in msg:
                    if is_calib:
                        # Create a new event
                        current_event = StimEvent()
                        # Set flags for next event
                        event_complete = False
                        v5_reading_found = False
                        continue

                # First look for console output of levels
                if ("config L" in msg) and not ("config LEGID" in msg):
                    lvl = int(msg[len("config L")])
                    ma = int(msg[len("config L? ") : len("config L? ") + 8], 16)
                    current_event.stim_levels.set_level(lvl, ma)
                    # print(current_event.stim_levels.get_level(lvl))

                # In subsequent logs, look for ramp events to determine
                # what level the therapy is being set to
                if "Ramp I_peak from" in msg:
                    second_half = msg.split(" to ")[1]
                    float_ramp_to_val = second_half.split(" mA ")[0]
                    int_ramp_to_val = int(float_ramp_to_val.split(".")[0])
                    try:
                        if current_event.stim_levels.has_all_levels() or (
                            int_ramp_to_val != 0
                        ):
                            current_event.stim_levels.set_latest_level_by_val(
                                int_ramp_to_val
                            )
                    except ValueError as e:
                        # If we cant find the value in our levels table, and we arent
                        # ramping down to 0 at the end of therapy, raise this error
                        if current_event.stim_levels.has_all_levels() and (
                            int_ramp_to_val != 0
                        ):
                            print(msg)
                            raise e

                # Look for first vpeak reading 5min or more after start time
                # If VPeak > 58000mV, record this as "HIGH" in the V-5 column
                # Looking for a log string of format `log batt {BATTMV} temp {T1} {T2} peak {VPEAKMV}
                if not v5_reading_found and ("log batt" in msg) and ("peak" in msg):
                    if entry.ts_s - current_event.ts_start >= (60 * 5):
                        # print(f"V5 found: {msg}");
                        v5_reading_found = True
                        vpeak_mv = int(msg.split(" ")[-1])  # Vpeak mV is the last value
                        if vpeak_mv > 58000:
                            current_event.v5 = "HIGH"

                """
                Then see if there is a known error REASON message. We will use
                this when we find the 'new state: Error' message later, but
                we need to keep track of it as the two messages wont be on the same
                line and not always with a fixed number of lines between them
                """
                if "EV_BatteryLow" in msg:
                    current_event.error_type = "BATT"
                elif "EV_OverTemp" in msg:
                    current_event.error_type = "HEAT"

                # Now look for other end reason messages
                if "EV_TherapyTimerExpired" in msg:
                    current_event.end_reason = "TIMER"
                elif "EV_DownHeld_3s" in msg:
                    current_event.end_reason = "USER"
                elif "EV_Plugged" in msg:
                    current_event.end_reason = "PLUG"
                elif "MainFSM new state: Error" in msg:
                    current_event.end_reason = "ERROR"

                # Finally, look for an end-of-therapy confirmation
                if "Waveform finish" in msg:
                    # Therapy completed normally, whether from error or other source
                    current_event.ts_end = entry.ts_s
                    current_event.dt_end = entry.dt
                    event_complete = True
                elif "boot" in msg:
                    # Therapy completed due to a hard reset or reboot
                    current_event.ts_end = entry.ts_s
                    current_event.dt_end = entry.dt
                    current_event.error_type = "BOOT"
                    current_event.end_reason = "ERROR"
                    event_complete = True

                if event_complete:
                    # Append event to stim event list
                    self.stim_events.append(current_event)
                    # Create a new event
                    current_event = StimEvent()
                    # Set flags for next event
                    event_complete = False
                    v5_reading_found = False
                    is_calib = True

        # for event in self.stim_events:
        #     print(event)


class LogParser(object):
    """High level parsing class. Takes in a series of logfile path names,
    passes these off to the LogFile class, then provides utilities for
    generating the session table or old-style outfile with timestamps
    converted to hours:min:seconds.milliseconds

    WARN: Logfile paths must be in OLDEST to NEWEST/MOST RECENT order"""

    def __init__(self, infile_paths=[], find_evts=True, find_imu=False):
        self.sessions = []
        self.log = LogFile(infile_paths, find_evts, find_imu)

    def generate_session_table(self, outpath=None):
        prev_dq_date = None
        total_days_used = 0
        for i, event in enumerate(self.log.stim_events):
            session = StimSession()
            session.session_num = i + 1
            session.stim_date = event.dt_start.strftime("%m/%d/%Y")
            session.stim_start_time = event.dt_start.strftime("%I:%M%p")
            session.stim_duration = event.duration_in_min
            session.v5 = event.v5

            # Determine end reason
            if event.end_reason == "ERROR":
                session.early_stop_reason = event.error_type
            elif event.end_reason != "TIMER":
                session.early_stop_reason = event.end_reason

            # Only calculate gap if not the first session in the logs
            if i > 0:
                session.gap_1_10th_days = round_up(
                    (
                        (
                            event.dt_start - self.log.stim_events[i - 1].dt_start
                        ).total_seconds()
                    )
                    / SECONDS_IN_DAY,
                    1,
                )

            # Calculate Daily Questionnaire Date (i.e. "the morning after")
            # Logic is: DQ Date is same day if start TS is between Midnight and Noon,
            #           DQ Date is next day if start TS is between Noon and Midnight
            if event.dt_start.hour < 12:
                session.dq_date = event.dt_start.strftime("%m/%d/%Y")
            else:
                delta = timedelta(days=1)
                session.dq_date = (event.dt_start + delta).strftime("%m/%d/%Y")

            # Calculate Days Used. Only reference prior days if NOT the first use in the session table
            if total_days_used == 0:
                total_days_used = 1
            elif prev_dq_date != session.dq_date:
                total_days_used += 1

            session.days_used = total_days_used

            prev_dq_date = session.dq_date

            # Determine latest stimulation level for this session
            session.latest_level = event.latest_level

            self.sessions.append(session)

        # print(",".join(SESSION_COLUMN_HEADERS))
        # for s in self.sessions:
        #     print(s.csvify())

        print(f"Writing session table to {outpath}")
        if outpath:
            with open(outpath, "w+") as f:
                f.write(",".join(SESSION_COLUMN_HEADERS) + "\n")
                f.writelines("\n".join([session.csvify() for session in self.sessions]))

        return self.sessions

    def generate_old_outfile(self, outpath):
        content = []

        # Convert timestamps, strip out any unparseable lines
        for (linenum, line) in enumerate(self.log.raw_content):
            line = line.rstrip("\r\n")
            m = re.search("^([0-9a-f]{8})[|](.*)$", line)
            if not m:
                # print("skipping line %d" % linenum)
                continue
            try:
                (ts, msg) = line.split("|")
            except ValueError as e:
                print(f"Found an erroneous log line, skipping: {line}")
                continue
            msec = int(ts, 16) * 10
            (h, m, s, ms) = (
                msec // (60 * 60 * 1000),
                (msec // (60 * 1000)) % 60,
                (msec // 1000) % 60,
                msec % 1000,
            )
            timestamp = "%02d:%02d:%02d.%03d" % (h, m, s, ms)
            content.append(timestamp + " " + msg)
            # print(timestamp, msg)

        # Write out ts_converted content
        print(f"Writing converted timestamp logs to {outpath}")
        with open(outpath, "w+") as f:
            f.writelines("\n".join(content))

    def generate_imu_file_list(self, outpath):



        print(f"Writing IMU file table to {outpath}")

        with open(outpath, "w+") as f:
            f.write(",".join(IMU_COLUMN_HEADERS) + '\n')
            f.writelines('\n'.join([imufile.csvify() for imufile in self.log.imu_files]))


if __name__ == "__main__":
    lp = LogParser(["inlog_1.txt", "inlog_2.txt"])
    # lp = LogParser(["tlog3.txt", "tlog2.txt", "tlog1.txt"])
    lp.generate_session_table("test_output_file.csv")
    lp.generate_old_outfile("test_old_output_file.csv")
