import re
from datetime import datetime
from distutils.version import LooseVersion
from time import time

EXPECTED_DATA_RATE = 9000 # bytes/second
LOG_FILE_TIME_QUERY_THRESHOLD_MINUTES = 3
LOG_DUMP_TIMEOUT_MINUTES = 75

IMU_DUMP_TIMEOUT_MINUTES = 120
IMU_DATA_RATE = EXPECTED_DATA_RATE / 2 # Due to cathex sending values as two ASCII chars vs one hex byte
IMU_FILE_TIME_QUERY_THRESHOLD_MINUTES = 5
IMU_BYTES_PER_HOUR = 2700000 # Conservative estimate of bytes/hr when downloading IMU data

LOG_LINE_REGEX = r"^([0-9a-f]{8})[|](.*)$" # Matches a log line with a timestamp and data

def get_remaining_imu(dev):
    """ Requires a TerminalDevice object for 'dev' input parameter.
        Returns remaining bytes and an estimate of remaining hours of IMU storage
    """
    print("Retrieving remaining log space on device...")

    fw_version = get_firmware_version(dev)
    if fw_version and fw_version < LooseVersion("v0.14"):
        imu_folder = "/log/data/"
    else:
        imu_folder = "/imu/"

    log_info = dev.transact(f"fs statvfs {imu_folder}", timeout=90)
    log_usage_re = re.compile(r'bsize \d+, frsize \d+, blocks \d+, bfree \d+')

    if log_info is None or not re.match(log_usage_re, log_info[0]):
        print(log_info)
        raise Exception(f"fs statvfs {imu_folder} command FAILED, aborting...")

    vals = re.findall(r'\d+', log_info[0])
    remaining_bytes = int(vals[3]) * int(vals[1]) # bfree (# of free blocks) * frsize (block size in bytes)
    remaining_hrs = remaining_bytes / IMU_BYTES_PER_HOUR

    return remaining_bytes, remaining_hrs

def erase_imu_files(dev):
    """ Requires a TerminalDevice object for 'dev' input parameter.
        Returns True if all files were erased successfully
        Returns False if there were no files to erase
        Raises an error if there were files present but failed to erase them
    """

    fw_version = get_firmware_version(dev)
    if fw_version and fw_version < LooseVersion("v0.14"):
        folder_prefix = "/log/data/"
    else:
        folder_prefix = "/imu/"

    # Retrieve IMU file list
    imu_file_list = get_imu_files_list(dev)

    if not imu_file_list:
        print("WARNING: No files to erase")
        return False

    print("Erasing all IMU data files...")
    # Delete each file
    for fn in imu_file_list:
        print(f"\tErasing {fn}...", end='')

        ret = dev.transact(f"fs rm {folder_prefix}{fn}")

        # Should be no response to this command. A response indicates an error
        if ret:
            print(f"\nResponse was: {ret}")
            raise Exception(f"FAILED to erase file {fn}, aborting...")

        print("Done.")

    print("All IMU data files erased")
    return True

def get_imu_files_list(dev):
    """ Requires a TerminalDevice object for 'dev' input parameter.
        Returns a list of file names
    """

    print("Retrieving IMU log file list...")
    imu_list = dev.transact("ls /log/data", timeout=90.0)

    imulog_re = re.compile(r'[0-9a-f]{8} mtnlog[0-9a-f]{8}.bin')
    total_re  = re.compile(r'total \d+ bytes')

    imu_log_list = []

    try:
        for file in imu_list:
            if re.match(imulog_re, file):
                file_name = file.split()[1]
                imu_log_list.append(file_name)
            elif re.match(total_re, file):
                continue
            else:
                print(file)
                raise Exception("LS /LOG/DATA/ command FAILED, aborting...")
    except Exception as e:
        print("Unable to retrieve IMU log list, response was:")
        print(imu_list)
        raise(e)

    return imu_log_list

def get_imu_files_dict(dev):
    """ Requires a TerminalDevice object for 'dev' input parameter.
        Returns a dict containing {FileName : FileSizeBytes}
    """

    print("Retrieving IMU log file list...")
    imu_list = dev.transact("ls /log/data", timeout=90.0)

    imulog_re = re.compile(r'[0-9a-f]{8} mtnlog[0-9a-f]{8}.bin')
    total_re  = re.compile(r'total \d+ bytes')

    imu_log_dict = {}

    try:
        for file in imu_list:
            if re.match(imulog_re, file):
                file_size = int(file.split()[0], 16)
                file_name = file.split()[1]
                imu_log_dict[file_name] = file_size
            elif re.match(total_re, file):
                total_size = int(re.search(r'\d+', file).group())
                imu_log_dict["All Files"] = total_size
            else:
                print(file)
                raise Exception("LS /LOG/DATA/ command FAILED, aborting...")
    except Exception as e:
        print("Unable to retrieve IMU log list, response was:")
        print(imu_list)
        raise(e)

    return imu_log_dict

def get_log_files_list(dev, silent: bool = False):
    """ Requires a TerminalDevice object for 'dev' input parameter.
        Returns a list of tuples: [(file name, file size)]
        Silent mode will not print any progress information.
    """

    if not silent: print("Retrieving log file list...")
    log_list = dev.transact("ls /log/", timeout=90.0)

    log_re = re.compile(r'[0-9a-f]{8} log[0-9a-f]{8}.txt')

    log_file_list = []

    try:
        for file in log_list:
            if re.match(log_re, file):
                file_name = file.split()[1]
                file_size = int(file.split()[0], 16)
                log_file_list.append((file_name, file_size))
    except Exception as e:
        print("Unable to retrieve log list, response was:")
        print(log_list)
        raise(e)

    return log_file_list

def get_file_size(dev):
    """ Requires a TerminalDevice object for 'dev' input parameter.
        Returns log file size in bytes if successful or False if not
    """

    print("Retrieving log file size before downloading...")
    log_list = dev.transact("ls /log/", timeout=90.0)
    if not log_list or not re.match(r'total \d+ bytes', log_list[-1]):
        print("Unable to retrieve log file size, response was:")
        print(log_list)
        raise Exception("LS /LOG/ command FAILED, aborting...")
    else:
        log_size_bytes = int(re.search(r'\d+', log_list[-1]).group())
        expected_transfer_time_s = (log_size_bytes / EXPECTED_DATA_RATE)
        expected_transfer_time_m = int(expected_transfer_time_s // 60)

    print(f"\nLog file size is {log_size_bytes} bytes.")

    # If we are below the specified threshold for estimated time, return immediately
    if expected_transfer_time_m <= LOG_FILE_TIME_QUERY_THRESHOLD_MINUTES:
        return log_size_bytes

    # Otherwise, ask the user if they would like to proceed
    while True:
        query = f"Log file transfer will take approximately {expected_transfer_time_m} minutes " + \
                 f"and {int(expected_transfer_time_s % 60)} seconds, would you like to proceed (Y/N)? "
        proceed = input(query)
        if proceed.upper() not in ["Y", "N"]:
            print(f'Error: Response must be Y or N, is "{proceed}"\n')
            continue
        elif proceed.upper() == "Y":
            return log_size_bytes
        else:
            return False

def enable_dfuprep_mode(dev):
    """ Requires a TerminalDevice object for 'dev' input parameter."""

    print("Disabling application console output while retrieving logs...")
    dev.transact("dfuprep", expecting_response=True)

def disable_dfuprep_mode(dev):
    """ Requires a TerminalDevice object for 'dev' input parameter."""

    print("Enabling application console output...")
    dev.transact("dfuprep", expecting_response=True)

def record_current_time_in_logs(dev):
    """ Requires a TerminalDevice object for 'dev' input parameter.
        Raises an exception if recording log message fails
    """

    print("Recording the current time in device logs...")
    current_time = datetime.now()
    timestamp = int(current_time.timestamp())
    log_str = f"Time is {timestamp}"
    ret = dev.transact(f"log msg {log_str}")

    if len(ret) != 1 or log_str not in ret[0]:
        # Response should be a single entry/line
        # Response should contain "Time is {timestamp}"
        print(f"Response was: {ret}")
        print(f"Expected to contain: {log_str}")
        raise Exception("LOG MSG command FAILED")

def retrieve_device_logs(dev, expected_size_bytes):
    """ Requires a TerminalDevice object for 'dev' input param
        Requires a number of expected bytes to be downloaded for 'expected_size_bytes' input param
    """

    start_time = time()
    print("Retrieving logs...")
    logs = dev.transact(
        "log dump", timeout=(60.0 * LOG_DUMP_TIMEOUT_MINUTES), use_tqdm=True, expected_size=expected_size_bytes
    )  # 3 minute timeout to allow for all logs to come in
    total_time = time() - start_time
    data_rate = expected_size_bytes / total_time
    print(f"Downloaded {expected_size_bytes} bytes of logs in {total_time:.2f}s ({data_rate:.2f} B/s)...")

    # Remove '### file /log/logxxxxxxxx.txt' entries
    logs = remove_file_headers_from_log_dump(logs)
    # Remove line breaks at the middle of log messages
    logs = remove_erroneous_line_breaks_from_logs(logs)

    return logs

def remove_file_headers_from_log_dump(logs):
    """ Helper method to remove file headers from log dump
        like '### file /log/logxxxxxxxx.txt\n' which might cut
        off a log message in the middle of a line.
        Returns a list of log lines without the file headers
    """
    regex = r"### file /log/log\w{8}\.txt"

    result = []
    previous_line = None

    for line in logs:
        if re.search(regex, line):
            previous_line = re.sub(regex, "", line)
        elif previous_line:
            previous_line += line
            result.append(previous_line)
            previous_line = None
        else:
            result.append(line)

    return result

def remove_erroneous_line_breaks_from_logs(logs):
    """ Helper method to remove erroneous line breaks from log dump
        like '00382441|Ramp I_peak from 10.000 mA to\r\n12.000 mA over 1000 msec'
        which might cut off a log message in the middle of a line.
        Returns a list of log lines without line breaks
    """

    result = []
    previous_line = None

    for line in logs:
        if re.search(LOG_LINE_REGEX, line):
            if previous_line:
                result.append(previous_line)
            previous_line = line
        elif previous_line:
            if line.startswith(" "):
                previous_line += line
                result.append(previous_line)
                previous_line = None
            else:
                result.append(previous_line)
                previous_line = None
                result.append(line)
        else:
            result.append(line)
            previous_line = None

    if previous_line:
        result.append(previous_line)

    return result

def retrieve_last_n_device_logs(dev, num_logs):
    """ Requires a TerminalDevice object for 'dev' input param
        Requires a number of most recent log files to download
    """

    start_time = time()
    print("Retrieving logs...")

    # Get file list before we start download
    log_files = get_log_files_list(dev)

    num_files_to_download = num_logs if num_logs <= len(log_files) else len(log_files)

    # Disable application console output
    enable_dfuprep_mode(dev)

    logs = []
    total_fsize = 0
    for fn, fsize in log_files[-num_files_to_download:]:
        print(f"Downloading {fn}...")
        log = dev.transact(f"cat /log/{fn}", use_tqdm=True, expected_size=fsize,
                           timeout=90)
        logs += log
        total_fsize += fsize

    # Re-enable application console output
    disable_dfuprep_mode(dev)

    total_time = time() - start_time
    data_rate = total_fsize / total_time
    print(f"Downloaded {total_fsize} bytes of logs in {total_time:.2f}s ({data_rate:.2f} B/s)...")

    # Remove line breaks at the middle of log messages
    logs = remove_erroneous_line_breaks_from_logs(logs)

    return logs

def get_firmware_version(dev):
    """ Requires a TerminalDevice object for 'dev' input param
        Returns the firmware LooseVersion or None
    """
    # Get firmware version
    version_dev = dev.transact("version")
    if not version_dev:
        print("Unable to retrieve version information, was None")
        return None

    # Parse firmware version
    version_str = next((part for part in version_dev if "Git revision" in part), None)
    version = version_str.replace("Git revision: ", "") if version_str else None
    if not version:
        print("Unable to parse version information, was None")
        return None
    return LooseVersion(version)

def get_leg_id(dev) -> int:
    """ Requires a TerminalDevice object for 'dev' input param
        Returns the leg ID [0=left, 1=right] or None
    """
    # Get leg ID (0=left, 1=right)
    ret = dev.transact("config get LEGID", timeout=0.5)

    # Response should be a single entry/line
    if len(ret) != 1:
        return None
    # Response should be convertable to an integer
    else:
        try:
            leg_id = int(ret[0])
            if leg_id not in [0, 1]:
                return None
        except ValueError:
            return None
    return leg_id

def get_serial_number(dev) -> int:
    """
    Requires a TerminalDevice object for 'dev' input parameter.
    Returns the serial number.
    """
    ret = dev.transact("config get SERID", timeout=0.5)
    # Response should be a single entry/line
    if len(ret) != 1:
        return None
    # Response should be convertable to an integer
    else:
        try:
            serial_number = int(ret[0])
        except ValueError:
            return None
    return serial_number

def get_estimated_download_time(log_files):
    """ Requires a TerminalDevice object for 'dev' input param
        Requires a list of tuples [(filename, filesize)]
        Returns a tuple with (estimated download time in seconds, total size in bytes)
    """

    log_size_bytes = sum([x[1] for x in log_files])
    expected_transfer_time_s = (log_size_bytes / EXPECTED_DATA_RATE)
    return (expected_transfer_time_s, log_size_bytes)

def get_log_file_ids(log_files):
    """ Requires a list of tuples [(filename, filesize)]
        Returns a list of log file IDs in integer format
    """

    return [int(x[0].replace("log", "").replace(".txt", ""), base=16) for x in log_files]

def get_next_log_files(dev, after_file_id: int):
    """ Requires a TerminalDevice object for 'dev' input param
        Requires a file ID in decimal to start after (not included) or None
        Returns a list of tuples [(filename, filesize)]
    """
    # Get log file list
    log_files = get_log_files_list(dev)
    if log_files is None or len(log_files) == 0:
        return []
    
    # Filter log files to only those after the specified file ID
    if after_file_id:
        after_file_name = f'log{hex(after_file_id).replace("0x", "").rjust(8, "0")}.txt'
        after_file_index = None
        for index, (fn, fsize) in enumerate(log_files):
            if fn == after_file_name:
                after_file_index = index
        if after_file_index:
            log_files = log_files[(after_file_index + 1):]
        else:
            print(f"Unable to find log file ID '{after_file_name}' in log file list")

    # Return log files
    return log_files

def retrieve_device_log_files(dev, log_files, silent: bool = False) -> str:
    """ Requires a TerminalDevice object for 'dev' input param
        Requires a list of tuples [(filename, filesize)]
        Returns the combined contents of the log files.
        Silent mode will not print any progress information.
    """
    # Begin download
    start_time = time()
    logs = []
    total_fsize = 0
    for fn, fsize in log_files:
        if not silent: print(f"Downloading {fn}...")
        log = dev.transact(f"cat /log/{fn}", use_tqdm=True, expected_size=fsize, timeout=90)
        if log:
            logs += log
        total_fsize += fsize

    # Display download time
    total_time = time() - start_time
    data_rate = total_fsize / total_time
    if not silent: print(f"Downloaded {total_fsize} bytes of logs in {total_time:.2f}s ({data_rate:.2f} B/s)...")

    # Remove None entries
    logs = [x for x in logs if x]

    # Remove line breaks at the middle of log messages
    logs = remove_erroneous_line_breaks_from_logs(logs)

    return logs

def end_log_file(dev):
    """ Requires a TerminalDevice object for 'dev' input param
    End the current verbose log file, if open
    """
    dev.transact("log end", timeout=0.5)
    dev.transact("log end_enc", timeout=0.5)