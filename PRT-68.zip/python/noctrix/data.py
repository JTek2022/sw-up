import struct


# Arbitrary ascii signature at beginning of data file
MAGIC = b"nDAT"
# header names for each bit in the <sources> bitfield,
# Should hopefully be agnostic to format (new sensors should be appended,
#   old sensors shouldn't be removed)
SOURCES = ["accelx", "accely", "accelz", "gyrox", "gyroy", "gyroz"]


class NoctrixDataFile(object):
    """A binary data file from a Noctrix device
    Contains time-series sensor data, with a small header.
    This base class must be implemented by versioned sub-classes.
    For example, NoctrixDataFileV1 should be a NoctrixDataFile where
    the <ver> value in the header is = 1."""

    def __init__(self):
        # These must all be updated by the subclass
        self.rowlen = 0
        self.sources = 0
        self.period_ms = 1000
        self.data = bytearray()
        self.schema = ""

    def to_tuples(self):
        """Retrieve the data as a list of tuples"""
        ret = []
        for idx in range(0, len(self.data), self.rowlen):
            try:
                ret.append(
                    struct.unpack_from(self.schema, self.data[idx : idx + self.rowlen])
                )
            except struct.error:
                break
        return ret

    def to_csv(self, filename):
        """Store the data in a csv file described by <filename>"""
        rows = self.to_tuples()
        with open(filename, "w") as fil:
            headertxt = "time,"
            for i in range(16):
                if self.sources & (1 << i):
                    headertxt += SOURCES[i] + ","
            headertxt = headertxt[:-1] + "\n"
            fil.write(headertxt)
            idx = 0
            for row in rows:
                rowtxt = "%.4f," % (idx * (self.period_ms / 1000.0))
                idx += 1
                for val in row:
                    rowtxt += str(val) + ","
                rowtxt = rowtxt[:-1] + "\n"
                fil.write(rowtxt)

    def to_dataframe(self, sources_to_plot=0xFF):
        """Retrieve the data as a Pandas DataFrame,
        Note: this requires an optional dependency of the python lib "pandas"
        This method will fail if Pandas is not installed."""
        import pandas as pd

        cols = []
        for i, source in enumerate(SOURCES):
            if self.sources & sources_to_plot & (1 << i):
                cols.append(source)

        data_to_plot = []
        for row in self.to_tuples():
            pruned_row = ()
            for i, data in enumerate(row):
                if sources_to_plot & (1 << i):
                    pruned_row += (data,)
            data_to_plot.append(pruned_row)

        df = pd.DataFrame(data_to_plot, columns=cols)
        df.index *= self.period_ms / 1000.0
        return df

    def plot(self, sources_to_plot=0xFF, interactive=False):
        """Open an interactive plot of the retrieved data.
        Note: this depends on both Pandas and Matplotlib,
        This method will fail if they are not available"""
        import matplotlib.pyplot as plt

        if interactive:
            plt.ion()
        df = self.to_dataframe(sources_to_plot)
        df.plot()
        if not interactive:
            plt.show()
        return df


class NoctrixDataFileV1(NoctrixDataFile):
    """A NoctrixDataFile with ver = 1
    This is a subclass of NoctrixDataFile.
    See NoctrixDataFile for most practical class methods"""

    MIN_LENGTH = 74

    def __init__(self, binarray):
        super().__init__()
        self.raw = binarray
        # This is the format implied by version 1
        args = struct.unpack_from("<LBBHH", binarray)
        self.magic = args[0]
        self.ver = args[1]
        self.rowlen = args[2]
        self.sources = args[3]
        self.period_ms = args[4]
        # The remaining bytes are one long c string
        remainder = binarray[10 : self.MIN_LENGTH]
        # Decode the c string by finding the null terminator and decoding it
        self.schema = remainder[: remainder.find(0)].decode("ascii")
        self.data = binarray[self.MIN_LENGTH :]


def parse_binarray(binarray):
    """Perform validation of a binary object and deserialize it"""
    if len(binarray) < 10:
        raise TypeError("Invalid Format: not enough data to parse")
    if binarray[:4] != MAGIC:
        raise TypeError("Invalid Format: magic %s != %s" % (binarray[:4], MAGIC))
    if binarray[4] == 1 and len(binarray) >= NoctrixDataFileV1.MIN_LENGTH:
        return NoctrixDataFileV1(binarray)
    else:
        raise TypeError("Invalid Format: unsupported version %d" % binarray[4])
