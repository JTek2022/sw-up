from noctrix.terminaldevice import TerminalDevice


class Device(TerminalDevice):
    def __init__(self, port=None, baud=115200, timeout=0.4, logger=None):
        super().__init__(port, baud, timeout, logger)

    def list_all_files(self):
        pass

    def _list_dir(self, directory):
        ret = self.transact("ls " + directory)
        # Trim the line specifying totals
        if ret[-1].startswith("total"):
            ret = ret[:-1]
        files = [(x.split(" ")[0].rstrip(), " ".join(x.split(" ")[1:])) for x in ret]
        return files
