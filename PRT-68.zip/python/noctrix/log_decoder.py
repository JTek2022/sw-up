import re

def safe_hex_to_decimal_string(hexValue):
    try: 
        return str(int(hexValue, 16))
    except: 
        return hexValue

class FileEntry(object):
    """
    Container class for log file entries.
    Simply stores the timestamp and message.
    """

    def __init__(self, ts, msg):
        self.ts = ts
        self.msg = msg

    def __str__(self):
        return f"{self.ts}|{self.msg}"


class LogDecoder(object):
    """
    Decodes encoded logs into regular verbose logs. Takes in a series of encoded logfile
    path names, then decodes them into a verbose logfile.
    """

    def __init__(self, infile_paths):
        self.infile_paths = infile_paths
        self.raw_content = []
        self.log_entries = []
        self.verbose_log_entries = []
        self.intake_files()
        self.decode_log_entries()

    def intake_files(self):
        self.raw_content = []
        # Read in raw logfile(s)
        for fn in self.infile_paths:
            with open(fn, "r+") as f:
                self.raw_content += f.readlines()

        # Pull out all the log lines
        for line in self.raw_content:
            stripped_line = line.rstrip("\r\n")
            m = re.search("^([0-9a-f]{8})[|](.*)$", stripped_line)
            if not m:
                # print("skipping line %d" % linenum)
                continue
            try:
                (ts, msg) = stripped_line.split("|")
            except ValueError as e:
                print(
                    f"Found an erroneous log line, skipping: {stripped_line}")
                continue

            self.log_entries.append(FileEntry(ts, msg))

        # for entry in self.log_entries:
        #     print(entry)

    def decode_log_entries(self):
        for i, entry in enumerate(self.log_entries):
            verbose_msg = self.map_encoded_entry_to_verbose_message(entry)
            self.verbose_log_entries.append(FileEntry(entry.ts, verbose_msg))

    def map_encoded_entry_to_verbose_message(self, entry):
        # Parse "key:data" or "key"
        msg = entry.msg
        if ":" in msg:
            entry_pair = entry.msg.split(":", 1)
            key = entry_pair[0]
            data = entry_pair[1]
        else:
            key = msg
        # region MAIN
        if key == "boot":
            data_parts = data.split(" ", 1)
            return "boot v" + data_parts[0] + " unknown-hw-rev " + data_parts[1]
        # endregion MAIN
        # region BLE_CMD_SVC
        elif key == "T":
            return "time is " + data
        elif key == "NF":
            return "New file opened..."
        # endregion BLE_CMD_SVC
        # region NOCTRIX_CONFIG
        elif key == "CS":
            data_parts = data.split(",")
            variable = data_parts[0]
            hexValue = data_parts[1]
            return "config set " + variable + " " + safe_hex_to_decimal_string(hexValue)
        # endregion NOCTRIX_CONFIG
        # region WAVEFORM
        elif key == "R":
            data_parts = data.split(">", 1)
            return "Ramp I_peak from " + data_parts[0] + ".000 mA to " + data_parts[1] + ".000 mA over 0 msec"
        elif key == "WF":
            return "Waveform finish"
        elif key == "WI":
            return "Waveform init"
        # endregion WAVEFORM
        # region MANAGER
        elif key == "SM":
            if data == "0":
                state = "Off"
            elif data == "1":
                state = "On"
            elif data == "2":
                state = "Error"
            elif data == "3":
                state = "Docked"
            elif data == "4":
                state = "DockedError"
            elif data == "5":
                state = "DockedDFUPrep"
            else:
                print(f"Found an unknown MainFSM line: {msg}")
                state = "Unknown " + data
            return "MainFSM new state: " + state
        elif key == "SB":
            if data == "0":
                state = "BothReleased"
            elif data == "1":
                state = "UpOnly"
            elif data == "2":
                state = "DownOnly"
            elif data == "3":
                state = "BothPressed"
            elif data == "4":
                state = "WaitForDownRelease"
            elif data == "5":
                state = "WaitForUpRelease"
            else:
                print(f"Found an unknown ButtonFSM line: {msg}")
                state = "Unknown " + data
            return "ButtonFSM new state: " + state
        elif key == "SW":
            if data == "0":
                state = "BTOff"
            elif data == "1":
                state = "BTIdentify"
            elif data == "2":
                state = "BTAdvertising"
            elif data == "3":
                state = "BTConnected"
            else:
                print(f"Found an unknown BluetoothFSM line: {msg}")
                state = "Unknown " + data
            return "BluetoothFSM new state: " + state
        elif key == "E":
            if data == "0":
                state = "EV_DownPressed"
            elif data == "1":
                state = "EV_DownReleased"
            elif data == "2":
                state = "EV_UpPressed"
            elif data == "3":
                state = "EV_UpReleased"
            elif data == "4":
                state = "EV_Up"
            elif data == "5":
                state = "EV_Down"
            elif data == "6":
                state = "EV_BothPressed"
            elif data == "7":
                state = "EV_DownHeld_3s"
            elif data == "8":
                state = "EV_UpHeld_3s"
            elif data == "9":
                state = "EV_BothHeld_3s"
            elif data == "10":
                state = "EV_BothReleased_10s"
            elif data == "11":
                state = "EV_AdvertisingStart"
            elif data == "12":
                state = "EV_AdvertisingStop"
            elif data == "13":
                state = "EV_Connected"
            elif data == "14":
                state = "EV_Disconnected"
            elif data == "15":
                state = "EV_StopTherapyBT"
            elif data == "16":
                state = "EV_ChargingStart"
            elif data == "17":
                state = "EV_ChargingStop"
            elif data == "18":
                state = "EV_ChargingSoftThresh"
            elif data == "19":
                state = "EV_Plugged"
            elif data == "20":
                state = "EV_Unplugged"
            elif data == "21":
                state = "EV_BatteryLow"
            elif data == "22":
                state = "EV_OverTemp"
            elif data == "23":
                state = "EV_TempWarning"
            elif data == "24":
                state = "EV_TempRecovered"
            elif data == "25":
                state = "EV_ErrorTimerExpired"
            elif data == "26":
                state = "EV_ButtonTimerExpired"
            elif data == "27":
                state = "EV_TherapyTimerExpired"
            elif data == "28":
                state = "EV_IdentifyTimerExpired"
            elif data == "29":
                state = "EV_CooldownTimerExpired"
            elif data == "30":
                state = "EV_AdvertiseTimerExpired"
            elif data == "31":
                state = "EV_WaveRampDone"
            elif data == "32":
                state = "EV_RestartLockTimer"
            elif data == "33":
                state = "EV_ToggleDFUPrep"
            else:
                print(f"Found an unknown EV_ line: {msg}")
                state = "EV_Unknown " + data
            return "send_event: " + state
        elif key == "C":
            data_parts = data.split(",")
            variable = data_parts[0]
            value = data_parts[1]
            return "config " + variable + " " + value.rjust(8, "0")
        elif key == "M":
            verbose_message = "log batt"
            if "," not in data:
                return verbose_message + " " + data
            else:
                data_parts = data.split(",")
                batt = safe_hex_to_decimal_string(data_parts[0])
                temp1 = safe_hex_to_decimal_string(data_parts[1])
                temp2 = safe_hex_to_decimal_string(data_parts[2])
                verbose_message += " " + batt + " temp " + temp1 + " " + temp2
                if len(data_parts) == 4:
                    peak = safe_hex_to_decimal_string(data_parts[3])
                    verbose_message += " peak " + peak
                return verbose_message
        elif key == "TOB":
            return "Turning on, battery: " + data
        elif key == "BTL":
            data_parts = data.split("<", 1)
            return "Battery too low (" + data_parts[0] + " < " + data_parts[1] + ")"
        elif key == "STT":
            return "started therapy timer " + data
        elif key == "BLL":
            data_parts = data.split("<", 1)
            return "Battery level low (" + data_parts[0] + " < " + data_parts[1] + ")"
        elif key == "BSC":
            data_parts = data.split(">", 1)
            return "Batt soft charged (" + data_parts[0] + " > " + data_parts[1] + ")"
        # endregion MANAGER
        # region NOCTRIX_DATALOG
        elif key == "DBW":
            return "Datalog: begin writing to mtnlog" + data + ".bin"
        elif key == "DNF":
            return "Datalog: new filename is mtnlog" + data + ".bin"
        elif key == "DPE":
            data_parts = data.split(",", 1)
            return "datalog push error @ " + data_parts[0] + " bytes, discarding " + data_parts[1] + " bytes..."
        elif key == "DLS":
            # TODO: This is not available on the firmware 0.13.0
            return "Datalog: Stopping (%\d samples recorded in %\d milliseconds)"
        # endregion NOCTRIX_DATALOG
        # region NOCTRIX_LOG
        elif key == "LE":
            return "logs erased"
        # endregion NOCTRIX_LOG
        else:
            print(f"Found an unknown key line: {msg}")
            return "Unknown encoded message " + msg

    def generate_verbose_file(self, outpath=None):
        # print(f"Writing verbose logs to {outpath}")
        if outpath:
            with open(outpath, "w+") as f:
                f.writelines("\n".join([str(verbose_entry)
                             for verbose_entry in self.verbose_log_entries]))


if __name__ == "__main__":
    lp = LogDecoder(["example1-input-encoded.txt",
                    "example1-input-encoded.txt"])
    lp.generate_verbose_file("example1-output-verbose.txt")
