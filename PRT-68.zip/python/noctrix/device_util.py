from enum import Enum

class LegId(Enum):
    LEFT = 0
    RIGHT = 1

    @property
    def name(self):
        if self == LegId.LEFT:
            return "L"
        elif self == LegId.RIGHT:
            return "R"
        else:
            return "U"