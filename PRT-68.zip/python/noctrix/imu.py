import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from bitarray import bitarray

# Data is stored like so:
# [FIFO_DATA_OUT_TAG, FIFO_DATA_OUT_X_L, FIFO_DATA_OUT_X_H, FIFO_DATA_OUT_Y_L, FIFO_DATA_OUT_Y_H, FIFO_DATA_OUT_Z_L, FIFO_DATA_OUT_Z_H]
# [FIFO_DATA_OUT_TAG, FIFO_DATA_OUT_X_L, FIFO_DATA_OUT_X_H, FIFO_DATA_OUT_Y_L, FIFO_DATA_OUT_Y_H, FIFO_DATA_OUT_Z_L, FIFO_DATA_OUT_Z_H]
# [FIFO_DATA_OUT_TAG, FIFO_DATA_OUT_X_L, FIFO_DATA_OUT_X_H, FIFO_DATA_OUT_Y_L, FIFO_DATA_OUT_Y_H, FIFO_DATA_OUT_Z_L, FIFO_DATA_OUT_Z_H]
# [FIFO_DATA_OUT_TAG, FIFO_DATA_OUT_X_L, FIFO_DATA_OUT_X_H, FIFO_DATA_OUT_Y_L, FIFO_DATA_OUT_Y_H, FIFO_DATA_OUT_Z_L, FIFO_DATA_OUT_Z_H]
# [FIFO_DATA_OUT_TAG, FIFO_DATA_OUT_X_L, FIFO_DATA_OUT_X_H, FIFO_DATA_OUT_Y_L, FIFO_DATA_OUT_Y_H, FIFO_DATA_OUT_Z_L, FIFO_DATA_OUT_Z_H]
# [FIFO_DATA_OUT_TAG, FIFO_DATA_OUT_X_L, FIFO_DATA_OUT_X_H, FIFO_DATA_OUT_Y_L, FIFO_DATA_OUT_Y_H, FIFO_DATA_OUT_Z_L, FIFO_DATA_OUT_Z_H]
# [FIFO_DATA_OUT_TAG, FIFO_DATA_OUT_X_L, FIFO_DATA_OUT_X_H, FIFO_DATA_OUT_Y_L, FIFO_DATA_OUT_Y_H, FIFO_DATA_OUT_Z_L, FIFO_DATA_OUT_Z_H]


"""
    From sensor types (see https://www.st.com/resource/en/datasheet/lsm6dso.pdf, page 87 - FIFO_DATA_OUT_TAG (78h) ):

    We only care about Gyroscope NC, Accelerometer NC, and Timestamp

    0x01 Gyroscope NC
    0x02 Accelerometer NC
    0x03 Temperature
    0x04 Timestamp

"""


class InvalidHeaderException(Exception):
    pass


class InvalidSensorTagException(Exception):
    pass


MAGIC_NUMBER = b"nDAT"
HEADER_LENGTH = 6  # in bytes
PACKET_LENGTH = 7  # in bytes


class SensorTag:
    GYRO = 0x01
    ACCEL = 0x02
    TIMESTAMP = 0x04


class FifoDataOutTagSensorRegisterMap:
    TagSensor4 = 0
    TagSensor3 = 1
    TagSensor2 = 2
    TagSensor1 = 3
    TagSensor0 = 4
    TagCount1 = 5
    TagCount0 = 6
    TagParity = 7


class FifoPacket:
    # Accel sensor sensitivity grain is 61 ug/LSB
    GAIN_UNIT_XL = 61
    # Gyro sensor sensitivity grain is 4.375 udps/LSB
    GAIN_UNIT_GY = 4375
    # Timestamp sensitivity grain is 25us/LSB
    GAIN_UNIT_TS = 25000

    @staticmethod
    def read_tag(tag_byte) -> SensorTag:
        tag = bitarray()
        tag.frombytes(tag_byte)
        tag = tag >> 3
        tag = int.from_bytes(tag.tobytes(), "big")

        if tag in [SensorTag.GYRO, SensorTag.ACCEL, SensorTag.TIMESTAMP]:
            return tag
        else:
            raise InvalidSensorTagException("Invalid tag detected, exiting")

    @staticmethod
    def read_sample(data_bytes, tag: SensorTag, freq_fine=None):
        x = y = z = ts = None
        if tag == SensorTag.ACCEL:
            x = FifoPacket._convert_accel(data_bytes[0:2])
            y = FifoPacket._convert_accel(data_bytes[2:4])
            z = FifoPacket._convert_accel(data_bytes[4:6])
            return (x, y, z)
        elif tag == SensorTag.GYRO:
            x = FifoPacket._convert_gyro(data_bytes[0:2])
            y = FifoPacket._convert_gyro(data_bytes[2:4])
            z = FifoPacket._convert_gyro(data_bytes[4:6])
            return (x, y, z)
        elif tag == SensorTag.TIMESTAMP:
            ts = FifoPacket._convert_timestamp(data_bytes[0:4], freq_fine)
            return ts

    @staticmethod
    def _convert_accel(raw):
        # First convert the raw values based on sensitivity
        # Sensitivity is exposed in ug/LSB
        # Return in units of Gs
        raw_val = int.from_bytes(raw, "little", signed=True)
        dval = raw_val * FifoPacket.GAIN_UNIT_XL
        return dval / 1000000

    @staticmethod
    def _convert_gyro(raw):
        # First convert the raw values based on sensitivity
        # Sensitivity is exposed in udps/LSB
        # Return in units of dps
        raw_val = int.from_bytes(raw, "little", signed=True)
        dval = raw_val * FifoPacket.GAIN_UNIT_GY
        return dval / 1000000

    @staticmethod
    def _convert_timestamp(raw, freq_fine):
        # First convert the raw value based on sensitivity
        # Sensitivity is exposed in us/LSB
        # Return in units of seconds
        raw_val = int.from_bytes(raw, "little")

        # Calculate the real TS units using the freq_fine trim value
        # Get IMU internal frequency register to be used to trim
        # generated timestamps with respec tto the effective ODR.
        # See LSM6DSO datasheet/app note for description.
        # linearize the AN5192 formula:
        #       1 / (1 + x) ~= 1 - x (Taylor’s Series)
        #       ttrim[s] = 1 / (40000 * (1 + 0.0015 * val))
        #       ttrim[ns] ~= 25000 - 37.5 * val
        #       ttrim[ns] ~= 25000 - (37500 * val) / 1000
        ts_gain = FifoPacket.GAIN_UNIT_TS
        if freq_fine != None:
            ts_gain -= (int(freq_fine) * 37500) / 1000

        dval = raw_val * (ts_gain / 1000)
        return dval / 1000000


class Datafile:
    def __init__(self, path, debug=False) -> None:
        self.debug = debug
        self.path = path
        self.raw = None
        self.position = 0
        self.freq_fine = None
        self.ver = None

        with open(self.path, "r") as f:
            self.raw = bytes.fromhex(f.read())


    def process(self, *, output_path):
        try:
            self.header = self._read_header()
        except AssertionError:
            raise InvalidHeaderException("Invalid header detected, exiting")

        accel = []
        gyro = []

        accel_ts = None
        gyro_ts = None

        last_timestamp = None
        discard = 0
        while (self.position + PACKET_LENGTH) <= len(self.raw):
            raw_packet = self.raw[self.position : self.position + PACKET_LENGTH]

            # Try reading the tag
            try:
                sensor_tag = FifoPacket.read_tag(raw_packet[0:1])

                # Tag successfully processed -- advance by one full packet
                if discard:
                    print(f"discarded {discard} bytes at {self.position}")
                self.position += PACKET_LENGTH
                discard = 0

            except InvalidSensorTagException:
                # Invalid tag -- advance by one byte until we re-sync
                self.position += 1
                discard += 1
                if discard >= PACKET_LENGTH:
                    # failed to sync
                    raise
                continue

            val = FifoPacket.read_sample(
                raw_packet[1:PACKET_LENGTH], sensor_tag, self.freq_fine
            )

            if sensor_tag == SensorTag.TIMESTAMP:
                if self.debug:
                    print(f"TS: {val:.6f}")

                if last_timestamp and abs(val - last_timestamp) > 100:
                    print(f"ignored bogus timestamp {val:.6f}, "
                          f"last was {last_timestamp:.6f}")
                else:
                    # This timestamp is good.  Save copies for both accel & gyro
                    # use, the next time we get one of those samples.
                    last_timestamp = val
                    accel_ts = val
                    gyro_ts = val

            elif sensor_tag == SensorTag.ACCEL:
                if accel_ts:
                    accel.append((accel_ts, val[0], val[1], val[2]))
                    accel_ts = None
                else:
                    accel.append((float("NAN"), val[0], val[1], val[2]))

                if self.debug:
                    print(
                        f"XL:({val[0]:5.2f}, {val[1]:5.2f}, {val[2]:5.2f})"
                    )

            elif sensor_tag == SensorTag.GYRO:
                if gyro_ts:
                    gyro.append((gyro_ts, val[0], val[1], val[2]))
                    gyro_ts = None
                else:
                    gyro.append((float("NAN"), val[0], val[1], val[2]))

                if self.debug:
                    print(
                        f"GY:({val[0]:5.2f}, {val[1]:5.2f}, {val[2]:5.2f})"
                    )

        accel = np.array(accel)
        accel_df = pd.DataFrame({
            "timestamp": accel[:,0],
            "x": accel[:,1],
            "y": accel[:,2],
            "z": accel[:,3]}).interpolate(method="linear")

        gyro = np.array(gyro)
        gyro_df = pd.DataFrame({
            "timestamp": gyro[:,0],
            "x": gyro[:,1],
            "y": gyro[:,2],
            "z": gyro[:,3]}).interpolate(method="linear")

        # Write CSVs to disk
        accel_df.to_csv(f"{output_path}/accel.csv", index=False)
        gyro_df.to_csv(f"{output_path}/gyro.csv", index=False)

        # Write plots to disk
        self._save_plot_from_dataframe(df=gyro_df, path=f"{output_path}/gyro.png")
        self._save_plot_from_dataframe(df=accel_df, path=f"{output_path}/accel.png")

    def _save_plot_from_dataframe(self, *, df, path):
        plt.clf()

        ax = plt.gca()
        ax.relim()
        ax.autoscale()  # auto-scale

        df.plot(kind="line", x="timestamp", y="x", ax=ax)
        df.plot(kind="line", x="timestamp", y="y", ax=ax)
        df.plot(kind="line", x="timestamp", y="z", ax=ax)

        plt.savefig(path)

    def _read_header(self):
        header = self.raw[self.position : HEADER_LENGTH]

        magic_number = header[0:4]
        self.freq_fine = header[4]

        print(f"Freq fine is {int(self.freq_fine)}")

        self.ver = header[5]

        assert magic_number == MAGIC_NUMBER

        self.position += HEADER_LENGTH
