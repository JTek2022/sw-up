try:
    from log_parser import StimSession, round_up
except ModuleNotFoundError:
    from noctrix.log_parser import StimSession, round_up

from datetime import datetime, timedelta
from statistics import mean

ANALYSIS_COLUMN_HEADERS = [
    "",
    "R-leg",
    "L-leg",
    "Total",
    "Follow-up",
    "Error dates",
    "Action",
]

### CLASS AGNOSTIC UTILITY FUNCTIONS ###

def intakeStimSessionCSV(fn):
    """Read in a parsed log file/stim session table (from LogParser)
    and return an array of StimSession objects.

    WARN: This assumes you are actually passing it a properly formatted
    StimSession CSV and does not perform any error checking
    """


    with open(fn, 'r+') as f:
        flines = f.readlines()

    stimSessions = []

    """
    The first row is a header row. Skip it then parse
    the remaining rows into StimSession objects.

    Column format:
    #,DQ Date,Stim time,Stim dur.,Stop early,Days used,Gap,Stim date,Stim time,LVL,V-5
    """
    for line in flines[1:]:
        session = StimSession()

        cols = line.split(",")

        session.session_num = cols[0]
        session.dq_date = cols[1]
        session.stim_start_time = cols[2]
        session.stim_duration = cols[3]
        session.early_stop_reason = cols[4]
        session.days_used = cols[5]
        session.gap_1_10th_days = cols[6]
        session.stim_date = cols[7]
        # Skip cols[8] - duplicate of stim_start_time
        session.latest_level = cols[9]
        session.v5 = cols[10]

        stimSessions.append(session)

    return stimSessions


def appendIfUnique(listToBeAppended, itemToAppend):
    if itemToAppend not in listToBeAppended:
        listToBeAppended.append(itemToAppend)

def parse_date(date, use_time=False):
    """
    Try to parse a date using several formats, warn about
    problematic value if the date does not match
    any of the formats tried
    """
    if use_time:
        formats = ('%m/%d/%Y%I:%M%p', '%m/%d%I:%M%p')
    else:
        formats = ('%m/%d/%Y', '%m/%d')
    for format in formats:
        try:
            return datetime.strptime(date, format)
        except ValueError:
            pass
    raise ValueError(f"Non-valid date format for date {date}. Supported formats: {formats}")

### LOG ANALYSIS OBJECTS/CLASSES ###

ERROR_DATES_DELIM = "; "

class AnalysisResult(object):
    """Container class for Device Log Analysis reults. Used to store various
    results from the device log analysis process. The "name" is the analysis
    category and the rest of the fields/columns are fixed to the format:

    Name , R-Leg, L-Leg, Total, Followup, Error Dates

    Provides an easy method to convert this to a .csv format for file output
    """

    def __init__(self, name=""):
        self.name = name
        self.r_leg = "-"
        self.l_leg = "-"
        self.total = "-"
        self.followup = "-"
        self.error_dates = "-"
        self.action = "-"

    def csvify(self):
        return str(self).replace(" | ", ",")

    def __str__(self):
        s = f"{self.name} | {self.r_leg} | {self.l_leg} | {self.total} | {self.followup} | {self.error_dates} | {self.action}"
        return s


class LogAnalysisPrompts(object):
    """Container class to hold the answers to prompts required
    for log analysis.
    """

    def __init__(self):
        self.eval_num = 0                   # "N"
        self.start_date = ""                # "SD"
        self.end_date = ""                  # "ED"

    def execute_prompts(self, prompt_data):
        if prompt_data is None:
            for prompt in [self.get_eval_num, self.get_start_date, self.get_end_date]:
                print("")
                prompt()
        else:
            if prompt_data.eval_num == 0:
                print("")
                self.get_eval_num()
            else:
                self.eval_num = prompt_data.eval_num
            if prompt_data.start_date == "":
                print("")
                self.get_start_date()
            else:
                self.start_date = prompt_data.start_date
            if prompt_data.end_date == "":
                print("")
                self.get_end_date()
            else:
                self.end_date = prompt_data.end_date

    def get_eval_num(self):
        while True:
            resp = input("Which evaluation # is this? ")
            if not resp.isnumeric():
                print(f"Error: Evaluation must be a number, is \"{resp}\"")
                continue
            break

        self.eval_num = int(resp)

    def get_start_date(self):
        while True:
            resp = input(f"Enter start of the analysis date range in MM-DD-YYYY format: ")
            try:
                resp_dt = datetime.strptime(resp, "%m-%d-%Y")
            except ValueError:
                print(f"Error: Start date must be in MM-DD-YYYY format, is \"{resp}\"")
                continue
            break

        print(f"Start of date range is: {resp}")

        self.start_date = resp_dt

    def get_end_date(self):
        while True:
            resp = input(f"Enter end of the analysis date range in MM-DD-YYYY format: ")
            try:
                resp_dt = datetime.strptime(resp, "%m-%d-%Y")
                if (resp_dt <= self.start_date):
                    print(f"Error: End date must be AFTER the Start date, is \"{resp}\"")
                    continue
            except ValueError:
                print(f"Error: End date must be in MM-DD-YYYY format, is \"{resp}\"")
                continue
            break

        print(f"End of date range is: {resp}")

        self.end_date = resp_dt

class LogAnalyzer(object):
    """Class for performing log file session table output analysis per Noctrix Automated
    Device Log Analysis specifications.
    """

    def __init__(self):
        self.results = []
        self.prompts = LogAnalysisPrompts()
        self.sessions_left  = None
        self.sessions_right = None

        self.start_dt = None
        self.end_dt = None
        self.start_ts = 0
        self.end_ts = 0

        # These process steps should match the rows in the spec document
        self.process_steps = [ self._step_days_with_completed_session,
                               self._step_total_completed_sessions,
                               self._step_days_with_attempted_session,
                               self._step_mismatched_timing,
                               self._step_L1_sessions,
                               self._step_USER_error_sessions,
                               self._step_BATT_error_sessions,
                               self._step_IMPEDANCE_error_sessions,
                               self._step_HEAT_error_sessions,
                               self._step_PLUG_error_sessions,
                               self._step_ERROR_error_sessions,
                               self._step_average_time_of_use
                            ]

    def intake_files(self, fn_left=None, fn_right=None):
        if not fn_left and not fn_right:
            raise Exception("Must supply at least one legs worth of parsed log data (both missing)")

        self.sessions_left  = intakeStimSessionCSV(fn_left) if fn_left else []
        self.sessions_right = intakeStimSessionCSV(fn_right) if fn_right else []

    def process(self, prompt_data = None):
        # Get prompt data
        self.prompts.execute_prompts(prompt_data)

        # Only proceed if session is within valid date range
        self.start_dt = self.prompts.start_date.replace(hour=12)
        self.start_ts = self.start_dt.timestamp()
        self.end_dt   = self.prompts.end_date.replace(hour=23, minute=59)
        self.end_ts   = self.end_dt.timestamp()


        # Process individual rows/analysis results
        for step in self.process_steps:
            self.results.append(step())

        # for res in self.results: print(res)

        return self.results


    ### UTILITY FUNCTIONS ###

    def generate_outfile(self, fn="DLA-results.csv"):

        print(f"\nWriting Log Analysis output file to {fn}...")

        with open(fn, "w+") as f:
            f.write(",".join(ANALYSIS_COLUMN_HEADERS) + "\n")
            f.writelines("\n".join([result.csvify() for result in self.results]))

    def _get_sessions_by_duration(self, sessions, min_dur = 0):
        """Finds all sessions in an array of StimSession objects (`sessions`) with a
        duration of `min_dur` MINUTES or greater, WITHIN THE DATE RANGE specified
        during the initial prompts and returns an array containing just those
        StimSession objects
        """

        completed_sessions = []
        completed_sessions_dt = [] # Datetime objects of completed sessions
        for session in sessions:
            session_dt = parse_date(session.dq_date)

            """Determine year for session. Assume that if the month is EARLIER than
            the eval date (start of date range), then the year is the FOLLOWING year.
            If the month is the SAME or LATER than the eval date, then the session
            year is the SAME year.
            """
            if session_dt.month < self.prompts.start_date.month:
                session_dt = session_dt.replace(year=self.prompts.start_date.year+1)
            else:
                session_dt = session_dt.replace(year=self.prompts.start_date.year)

            # Only proceed if session is within valid date range
            session_ts = session_dt.timestamp()
            if (session_ts < self.start_ts) or (session_ts > self.end_ts):
                # print(f"Skipping session {session.session_num} - ts: {session_ts} out of range ({self.start_ts} to {self.end_ts}")
                continue

            """Special Case: If the first row has code USER and occurs on the same date as
            the start of date range, then remove it prior to analysis.  This corresponds
            to a “practice” use in the clinic.
            """
            stim_dt = parse_date(session.stim_date)
            if (len(completed_sessions) == 0) and \
               (stim_dt.month == self.prompts.start_date.month) and \
               (stim_dt.day   == self.prompts.start_date.day) and \
               (session.early_stop_reason == "USER"):
               continue

            # Only add the current date to the list of days with correct use if
            # the session duration is >= min_dur
            if (int(session.stim_duration) >= min_dur):
                completed_sessions.append(session)

        return completed_sessions

    def _get_unique_dates_from_sessions(self, sessions):
        """Create and return a list of unique MM/DD dates within a list of sessions"""

        unique_dates = []
        for session in sessions:
            appendIfUnique(unique_dates, session.dq_date)

        return unique_dates

    def _get_early_stop_result(self, name, error_str):
        """Calculations 6, 7, 9, 10, and 11 all perform the same process against
        a different string. This function-izes that process. Find sessions in which
        the early stop reason was 'error_str'.

        'name' expects a string to be used for the name of an AnalysisResult object
        'error_str' expects a string
        """

        res = AnalysisResult(name)

        left_sessions  = self._get_sessions_by_duration(self.sessions_left, min_dur=0)
        right_sessions = self._get_sessions_by_duration(self.sessions_right, min_dur=0)

        error_dates = []

        """Calculate any sessions w error == 'error_str', add the date of this error to list if
        it has not already been added
        """
        res.l_leg = 0
        for session in left_sessions:
            if session.early_stop_reason == error_str:
                res.l_leg += 1
                appendIfUnique(error_dates, session.dq_date)

        res.r_leg = 0
        for session in right_sessions:
            if session.early_stop_reason == error_str:
                res.r_leg += 1
                appendIfUnique(error_dates, session.dq_date)

        # Determine whether followup is required
        if res.r_leg or res.l_leg:
            res.followup = "Yes"

        # Add error dates
        if (len(error_dates) != 0):
            res.error_dates = ERROR_DATES_DELIM.join(error_dates)

        return res

    ### CALCULATIONS/INDIVIDUAL ANALYSIS STEP FUNCTIONS ###

    #These functions will always return an AnalysisResult object

    ### Calculation 1
    def _step_days_with_attempted_session(self):
        """ A “day” is defined as noon to noon. A “day with device use”
        is defined as at least one stimulation session initiated within
        the day (even if only 1min). Total for this calculation include
        each day with R or L or both. The purpose of this is “intended use”.
        """

        res = AnalysisResult("Days with attempted session")

        left_sessions      = self._get_sessions_by_duration(self.sessions_left, min_dur=0)
        left_unique_dates  = self._get_unique_dates_from_sessions(left_sessions)

        right_sessions     = self._get_sessions_by_duration(self.sessions_right, min_dur=0)
        right_unique_dates = self._get_unique_dates_from_sessions(right_sessions)

        # Create an array containing the combined unique dates from both L and R legs
        total_unique_dates = left_unique_dates[:]
        for date in right_unique_dates:
            appendIfUnique(total_unique_dates, date)

        # Assign unique dates values to response object
        res.l_leg = len(left_unique_dates)
        res.r_leg = len(right_unique_dates)
        res.total = len(total_unique_dates)

        return res

    ### Calculation 2
    def _step_days_with_completed_session(self):
        """A “day” is defined as noon to noon. For Total, a correct day of use
        requires at least one completed 30min session from R and at least one
        completed 30min session from L. The purpose of this is “correct use”.
        For each of R-leg and L-leg, a correct day of use involves at least one
        completed 30min session from that leg.
        """

        res = AnalysisResult("Days with completed session")

        left_30min_sessions  = self._get_sessions_by_duration(self.sessions_left, min_dur=30)
        left_unique_dates    = self._get_unique_dates_from_sessions(left_30min_sessions)

        right_30min_sessions = self._get_sessions_by_duration(self.sessions_right, min_dur=30)
        right_unique_dates   = self._get_unique_dates_from_sessions(right_30min_sessions)

        # Create an array containing the combined unique dates from both L and R legs
        total_unique_dates = left_unique_dates[:]
        for date in right_unique_dates:
            appendIfUnique(total_unique_dates, date)

        # Assign unique dates values to response object
        res.l_leg = len(left_unique_dates)
        res.r_leg = len(right_unique_dates)
        res.total = len(total_unique_dates)

        # Add action
        res.action = "Enter values into Question 2 on the worksheet"

        return res

    ### Calculation 3
    def _step_total_completed_sessions(self):
        """Total 30-min sessions for each leg."""

        res = AnalysisResult("Completed sessions")

        left_30min_sessions  = self._get_sessions_by_duration(self.sessions_left, min_dur=30)
        right_30min_sessions = self._get_sessions_by_duration(self.sessions_right, min_dur=30)

        # Assign total completed sessions values to response object
        res.l_leg = len(left_30min_sessions)
        res.r_leg = len(right_30min_sessions)

        # Add action
        res.action = "Enter values into Question 3 on the worksheet"

        return res

    ### Calculation 4
    def _step_mismatched_timing(self):
        """Total days with one or more 30-min session on one leg that doesn’t start within
        10-min of a 30-min session on the other leg.  If >0, Follow-up = “Yes”.  Otherwise,
        Follow-up = “-“.
        """

        res = AnalysisResult("Days with mismatched timing")

        # Skip this step if we don't have both L and R valid input data
        if not self.sessions_left or not self.sessions_right:
            return res

        def generate_session_dt_tuples(sessions):
            # Create a tuple of all session objects and their corresponding start time datetimes
            session_ts_pairs = []
            for session in sessions:
                session_dt = parse_date(session.stim_date+session.stim_start_time, use_time=True)

                """Determine year for session. Assume that if the month is EARLIER than
                the eval date (start of date range), then the year is the FOLLOWING year.
                If the month is the SAME or LATER than the eval date, then the session
                year is the SAME year.
                """
                if session_dt.month < self.prompts.start_date.month:
                    session_dt = session_dt.replace(year=self.prompts.start_date.year+1)
                else:
                    session_dt = session_dt.replace(year=self.prompts.start_date.year)

                """Only add the current session/timestamp to the list if the session
                duration is >= 30 min
                """
                if (int(session.stim_duration) >= 30):
                    session_ts_pairs.append((session, session_dt))

            return session_ts_pairs

        left_30min_sessions  = self._get_sessions_by_duration(self.sessions_left, min_dur=30)
        right_30min_sessions = self._get_sessions_by_duration(self.sessions_right, min_dur=30)

        # Get a UNIX timestamp for each session, create a list of tuples (session, datetime)
        left_session_dt_pairs  = generate_session_dt_tuples(left_30min_sessions)
        right_session_dt_pairs = generate_session_dt_tuples(right_30min_sessions)

        # Find mismatched datetimes
        mismatched_days = []
        # First compare left leg times against right
        for session_l, dt_l in left_session_dt_pairs:
            matched_session_found = False

            for session_r, dt_r in right_session_dt_pairs:
                if abs(dt_l - dt_r) < timedelta(minutes=10):
                    matched_session_found = True
                    break

            if not matched_session_found:
                appendIfUnique(mismatched_days, session_l.dq_date)

        # Then compare right leg times against left, using the same unique days list
        for session_r, dt_r in right_session_dt_pairs:
            matched_session_found = False

            for session_l, dt_l in left_session_dt_pairs:
                if abs(dt_r - dt_l) < timedelta(minutes=10):
                    matched_session_found = True
                    break

            if not matched_session_found:
                appendIfUnique(mismatched_days, session_r.dq_date)

        # Assign unique mismatched days to response object
        res.total = len(mismatched_days)
        res.error_dates = "; ".join(mismatched_days)

        # Assign follow-up if necessary
        if res.total != 0:
            res.followup = "Yes"

        # Add action if necessary
        if res.followup == "Yes":
            res.action = "Instruction: Turn on both R and L devices at the same time " + \
                         "(within a minute of each other)"

        return res


    ### Calculation 5
    def _step_L1_sessions(self):
        """Total 30-min sessions with intensity = L1.  If either L or R is >=50% of
        “Completed sessions”, Follow-up = “Yes”.  Otherwise, Follow-up = “-“
        """

        res = AnalysisResult("L1 sessions")

        left_30min_sessions  = self._get_sessions_by_duration(self.sessions_left, min_dur=30)
        right_30min_sessions = self._get_sessions_by_duration(self.sessions_right, min_dur=30)

        error_dates = []

        """Calculate 30-min sessions w intensity = L1 for each leg, add the date
        of this error to the list if it has not already been added
        """
        res.l_leg = 0
        for session in left_30min_sessions:
            if session.latest_level == "L1":
                res.l_leg += 1
                appendIfUnique(error_dates, session.dq_date)

        res.r_leg = 0
        for session in right_30min_sessions:
            if session.latest_level == "L1":
                res.r_leg += 1
                appendIfUnique(error_dates, session.dq_date)

        # Determine whether followup is required. Len of sessions lists == num completed sessions
        if (res.l_leg > (len(left_30min_sessions) / 2)) or (res.r_leg > (len(right_30min_sessions) / 2)):
           res.followup = "Yes"

        # Add error dates
        res.error_dates = ERROR_DATES_DELIM.join(error_dates)

        # Add action if necessary
        if res.followup == "Yes":
            res.action = "Instruction: Use + button to increase from L1 to L3 at start of stimulation " + \
                          "unless you experience discomfort at L3"

        return res

    ### Calculation 6
    def _step_USER_error_sessions(self):
        """Total sessions of any length with USER error. If >0, Follow-up = “Yes”.
        Otherwise, Follow-up = “-“.
        """

        res = self._get_early_stop_result("USER errors", "USER")

        # Add action if necessary
        if res.followup == "Yes":
            res.action = "Instruction: Let devices run for a full 30min unless you experience discomfort"

        return res

    ### Calculation 7
    def _step_BATT_error_sessions(self):
        """Total sessions of any length with BATT error. If >0, Follow-up = “Yes”.
        Otherwise, Follow-up = “-“.
        """

        res = self._get_early_stop_result("BATT errors", "BATT")

        # Add action if necessary
        if res.followup == "Yes":
            res.action = "Instruction: Charge batteries prior to each use - " + \
                         "Charge time approximately equals stimulation time"

        return res


    ### Calculation 8
    def _step_IMPEDANCE_error_sessions(self):
        """Total sessions of any length with V-5 = HIGH. If >0, Follow-up = “Yes”.
        Otherwise, Follow-up = “-“.
        """

        res = AnalysisResult("IMPEDANCE errors")

        left_sessions  = self._get_sessions_by_duration(self.sessions_left, min_dur=0)
        right_sessions = self._get_sessions_by_duration(self.sessions_right, min_dur=0)

        error_dates = []

        """Calculate any sessions w error == 'error_str', add the date of this error to list if
        it has not already been added
        """
        res.l_leg = 0
        for session in left_sessions:
            if session.v5.strip() == "HIGH":
                res.l_leg += 1
                appendIfUnique(error_dates, session.dq_date)

        res.r_leg = 0
        for session in right_sessions:
            if session.v5.strip() == "HIGH":
                res.r_leg += 1
                appendIfUnique(error_dates, session.dq_date)

        # Determine whether followup is required
        if res.r_leg or res.l_leg:
            res.followup = "Yes"

        # Add error dates
        res.error_dates = ERROR_DATES_DELIM.join(error_dates)

        # Add action if necessary
        if res.followup == "Yes":
            res.action = "Instruction: Contact sponsor"

        return res

    ### Calculation 9
    def _step_HEAT_error_sessions(self):
        """Total sessions of any length with HEAT error. If >0, Follow-up = “Yes”.
        Otherwise, Follow-up = “-“.
        """

        res = self._get_early_stop_result("HEAT errors", "HEAT")

        # Add action if necessary
        if res.followup == "Yes":
            res.action = "Instruction: Contact sponsor"

        return res

    ### Calculation 10
    def _step_PLUG_error_sessions(self):
        """Total sessions of any length with PLUG error. If >0, Follow-up = “Yes”.
        Otherwise, Follow-up = “-“.
        """

        res = self._get_early_stop_result("PLUG errors", "PLUG")

        # Add action if necessary
        if res.followup == "Yes":
            res.action = "Instruction: Don't plug device into charger while it's running"

        return res

    ### Calculation 11
    def _step_ERROR_error_sessions(self):
        """Total sessions of any length with ERROR error. If >0, Follow-up = “Yes”.
        Otherwise, Follow-up = “-“.
        """

        res = self._get_early_stop_result("ERROR errors", "ERROR")

        # Add action if necessary
        if res.followup == "Yes":
            res.action = "Instruction: Contact sponsor"

        return res

    ### Calculation 13: UNUSED/UNDEFIND

    ### Calculation 14: For each error, enter all the dates in the "error dates" column in MM/DD format

    ### Calculation 15/16
    def _step_average_time_of_use(self):
        """Enter average time of use for each leg centered at midnight such that average
        of 10pm and 1am is 23:30 and average of 11pm and 2am is 0:30. If average time of
        use for either leg is between 5:00 and 18:00, Follow-up = “Yes”.  Otherwise, Follow-up = “-“.
        """

        res = AnalysisResult("Average time of use")

        left_sessions  = self._get_sessions_by_duration(self.sessions_left, min_dur=0)
        right_sessions = self._get_sessions_by_duration(self.sessions_right, min_dur=0)

        # Create a list of session start times in a decimal hours format
        left_start_times = []
        for session in left_sessions:
            start_dt = datetime.strptime(session.stim_start_time, "%I:%M%p")
            start_time = start_dt.hour + (start_dt.minute / 60)
            # Offset times before Noon by 24hrs to center around midnight
            if start_dt.hour < 12: start_time += 24
            left_start_times.append(start_time)

        right_start_times = []
        for session in right_sessions:
            start_dt = datetime.strptime(session.stim_start_time, "%I:%M%p")
            start_time = start_dt.hour + (start_dt.minute / 60)
            # Offset times before Noon by 24hrs to center around midnight
            if start_dt.hour < 12: start_time += 24
            right_start_times.append(start_time)

        # Calculate average start times and convert to HH:MM format
        left_avg_dt = datetime.min
        if left_start_times:
            left_avg_start_time  = mean(left_start_times)
            avg_hour = int(left_avg_start_time)
            avg_minute = round_up((left_avg_start_time % 1) * 60)
            if (avg_minute == 60): avg_hour += 1

            left_avg_dt  = left_avg_dt.replace(hour=int(avg_hour % 24),
                                               minute=int(avg_minute % 60))

        right_avg_dt = datetime.min
        if right_start_times:
            right_avg_start_time = mean(right_start_times)
            avg_hour = int(right_avg_start_time)
            avg_minute = round_up((right_avg_start_time % 1) * 60)
            if (avg_minute == 60): avg_hour += 1

            right_avg_dt = right_avg_dt.replace(hour=int(avg_hour % 24),
                                                minute=int(avg_minute % 60))

        # Stuff result object
        res.l_leg = left_avg_dt.strftime("%H:%M")
        res.r_leg = right_avg_dt.strftime("%H:%M")

        if (left_start_times and (left_avg_dt.hour < 18) and (left_avg_dt.hour > 5)) or \
           (right_start_times and (right_avg_dt.hour < 18) and (right_avg_dt.hour > 5)):
            res.followup = "Yes"

        # Add action if necessary
        if res.followup == "Yes":
            res.action = "Instruction: It's okay to use devices during the day but recharge devices " + \
                         "afterwards and also use them when you have RLS symptoms in the evening and night"

        return res

if __name__ == '__main__':
    # prompts = LogAnalysisPrompts()
    # prompts.execute_prompts()

    # a = intakeStimSessionCSV("analysisexamples/testdata-L.csv")
    # for b in a: print(b)
    # a = intakeStimSessionCSV("analysisexamples/testdata-R.csv")
    # for b in a: print(b)

    la = LogAnalyzer()

    la.intake_files("analysisexamples/testdata-L.csv", "analysisexamples/testdata-R.csv")
    # la.intake_files("analysisexamples/testdata-L.csv", None)
    # la.intake_files(None, "analysisexamples/testdata-R.csv")
    # la.intake_files(None, None)
    # la.intake_files("analysisexamples/test-oneline.csv")

    la.process()
    # Below is test data used to bypass the prompts
    # prompts = LogAnalysisPrompts()
    # prompts.eval_num = 1
    # prompts.start_date = datetime.strptime("07-08-2021", "%m-%d-%Y")
    # prompts.end_date = datetime.strptime("07-20-2021", "%m-%d-%Y")
    # la.process(prompt_data=prompts)

    la.generate_outfile()
