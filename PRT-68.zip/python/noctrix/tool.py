import argparse
import logging
import collections
import sys
import time
from os import path
from datetime import datetime, timezone
from noctrix.terminaldevice import TerminalDevice
from noctrix.data import parse_binarray


FUNCS = {}


class NoctrixTool(object):
    COMMANDS = {}

    def __init__(self, port=None, baud=115200, debug=False, command=None, **kwargs):
        logging.basicConfig(level=logging.DEBUG if debug else logging.INFO)
        self.debug = debug
        self.command = command
        self.kwargs = kwargs
        self.funcs = {}
        self.dev = TerminalDevice(port, baud)

    def main(self):
        if self.command is None:
            print("You must specify a valid command!")
            return -1
        self.dev.open()
        if self.command is not None:
            self.COMMANDS[self.command](self)
        self.dev.close()
        return 0


class _HelpAction(argparse._HelpAction):
    def __call__(self, parser, namespace, values, option_string=None):
        parser.print_help()

        # retrieve subparsers from parser
        subparsers_actions = [
            action
            for action in parser._actions
            if isinstance(action, argparse._SubParsersAction)
        ]
        # there will probably only be one subparser_action,
        # but better safe than sorry
        print("")
        print("Where:")
        for subparsers_action in subparsers_actions:
            # get all subparsers and print help
            for choice, subparser in list(subparsers_action.choices.items()):
                print("  %s: \t%s" % (choice, subparser.description))

        parser.exit()


def parse_args(args=[]):
    """Parse arguments into a dictionary"""
    parser = argparse.ArgumentParser(
        description="Manage noctrix hardware devices", add_help=False
    )
    parser.add_argument(
        "-d",
        "--debug",
        default=False,
        action="store_true",
        help="Log debug messages to screen",
    )
    parser.add_argument(
        "-p", "--port", default=None, help="(Optional) Specify the serial port."
    )
    parser.add_argument(
        "-b", "--baud", default=115200, help="(Optional) Specify the serial baud rate."
    )
    parser.add_argument(
        "-h", "--help", action=_HelpAction, help="Print the help message"
    )
    sub = parser.add_subparsers(
        title="command", dest="command", description="Action to perform"
    )
    # Sort the dict of functions that NoctrixToolCommand decorator collected
    ORDERED_FUNCS = collections.OrderedDict(sorted(FUNCS.items()))
    for funcname in ORDERED_FUNCS:
        # Execute the _command_wrapper, which will add a parser to sub
        func = FUNCS[funcname](sub)
        # Store the function to be executed on NoctrixTool
        NoctrixTool.COMMANDS[funcname] = func

    if args:
        arguments = parser.parse_args(args)
    else:
        arguments = parser.parse_args()

    return vars(arguments)


# This decorator is a pattern for defining commands
# Each command needs to define a subparser so it can provide more args
# As well as a function to be called
def NoctrixToolCommand(command_name):
    def _command_decorator(func):
        # Store the returned function in FUNCS
        FUNCS[command_name] = func

        # Allow the command to apply an argument to the subparser
        def _subparser_wrapper(subparser):
            return func(subparser)

    return _command_decorator


def auto_int(x):
    return int(x, 0)


@NoctrixToolCommand("config-set")
def _config_set(subparser):
    parser = subparser.add_parser(
        "config-set", description="Set a config variable on the device"
    )
    parser.add_argument("var", help="The name of the config var to be set")
    parser.add_argument("val", help="The value to set the config var to")

    def dowork(app):
        ret = app.dev.transact(
            "config set " + app.kwargs["var"] + " " + app.kwargs["val"]
        )
        print("\n".join(ret))

    return dowork


@NoctrixToolCommand("config-get")
def __config_get(subparser):
    parser = subparser.add_parser(
        "config-get", description="Get a config variable on the device"
    )
    parser.add_argument("var", help="The name of the config var to be retrieved")

    def dowork(app):
        ret = app.dev.transact("config get " + app.kwargs["var"])
        print("\n".join(ret))

    return dowork


@NoctrixToolCommand("set-time")
def __set_time(subparser):
    parser = subparser.add_parser(
        "set-time", description="Record the current time (GMT) in the device log"
    )

    def dowork(app):
        timestamp = datetime.now(timezone.utc)
        ret = app.dev.transact(
            "log msg Time: " + timestamp.strftime("%Y-%m-%d %H:%M:%S:%f %Z")
        )
        print("\n".join(ret))

    return dowork


@NoctrixToolCommand("ls")
def __ls(subparser):
    parser = subparser.add_parser("ls", description="List the files on the device")
    parser.add_argument("path", default="/", help="Specify the path to display")

    def dowork(app):
        ret = app.dev.transact("ls " + app.kwargs["path"])
        print("\n".join(ret))

    return dowork


@NoctrixToolCommand("datalog-start")
def __datalog_start(subparser):
    parser = subparser.add_parser("datalog-start", description="Begin logging data")
    parser.add_argument("filename", help="The name of the remote file to log to")
    parser.add_argument(
        "--period",
        default=50,
        type=int,
        help="The period between samples, in milliseconds",
    )
    parser.add_argument(
        "--sensors",
        default=0xFF,
        type=auto_int,
        help="Bitfield of sensors to sample (default=all)",
    )
    parser.add_argument(
        "--stop-after",
        default=0,
        type=int,
        help="Stop sampling after this many samples (default=inf)",
    )

    def dowork(app):
        ret = app.dev.transact(
            "datalog_start %d 0x%02x %s %d"
            % (
                app.kwargs["period"],
                app.kwargs["sensors"],
                app.kwargs["filename"],
                app.kwargs["stop_after"],
            )
        )
        print("\n".join(ret))

    return dowork


@NoctrixToolCommand("datalog-stop")
def __datalog_stop(subparser):
    subparser.add_parser("datalog-stop", description="Stop logging data")

    def dowork(app):
        ret = app.dev.transact("datalog_stop")
        print("\n".join(ret))

    return dowork


@NoctrixToolCommand("datalog-csv")
def __datalog_csv(subparser):
    parser = subparser.add_parser(
        "datalog-csv", description="Convert a bin file on the device to a CSV file"
    )
    parser.add_argument("path", help="The name of the remote file to read")
    parser.add_argument(
        "--local-path",
        default=None,
        help="(Optional) Specify the local location to copy",
    )

    def dowork(app):
        print("Collecting log data, this may take up to 5 minutes for large files...")
        print("(Approx 1 minute for every 15 minutes of data collection)")
        ret = app.dev.transact("cathex " + app.kwargs["path"], timeout=300.00)
        data = [
            [int(line[x : x + 2], 16) for x in range(0, len(line), 2)] for line in ret
        ]
        bindata = bytearray()
        for row in data:
            bindata.extend(bytearray(row))
        if app.kwargs["local_path"] is None:
            app.kwargs["local_path"] = path.basename(app.kwargs["path"]) + ".csv"
        datafile = parse_binarray(bindata)
        datafile.to_csv(app.kwargs["local_path"])
        print(
            "Complete, %d bytes read, csv written to %s"
            % (len(bindata), app.kwargs["local_path"])
        )

    return dowork


@NoctrixToolCommand("datalog-plot")
def __datalog_plot(subparser):
    parser = subparser.add_parser(
        "datalog-plot", description="Read a bin file on the device and plot it"
    )
    parser.add_argument("path", help="The name of the remote file to read")
    parser.add_argument(
        "--sensors",
        default=0xFF,
        type=auto_int,
        help="Bitfield of sensors to plot (default=all)",
    )

    def dowork(app):
        print("Collecting log data, this may take up to 5 minutes for large files...")
        print("(Approx 1 minute for every 15 minutes of data collection)")
        ret = app.dev.transact("cathex " + app.kwargs["path"], timeout=300.00)
        data = [
            [int(line[x : x + 2], 16) for x in range(0, len(line), 2)] for line in ret
        ]
        bindata = bytearray()
        for row in data:
            bindata.extend(bytearray(row))
        datafile = parse_binarray(bindata)
        datafile.plot(app.kwargs["sensors"])

    return dowork


@NoctrixToolCommand("cat")
def __cat(subparser):
    parser = subparser.add_parser("cat", description="Print file contents")
    parser.add_argument("path", default="", help="Specify the file to open")

    def dowork(app):
        ret = app.dev.transact("cat " + app.kwargs["path"])
        print("\n".join(ret))

    return dowork


@NoctrixToolCommand("copy")
def __copy(subparser):
    parser = subparser.add_parser("copy", description="Copy a file off the device")
    parser.add_argument("path", default="", help="Specify the file to open")
    parser.add_argument(
        "--local-path",
        default=None,
        help="(Optional) Specify the local location to copy",
    )

    def dowork(app):
        ret = app.dev.transact("cathex " + app.kwargs["path"])
        data = [
            [int(line[x : x + 2], 16) for x in range(0, len(line), 2)] for line in ret
        ]
        bindata = bytearray()
        for row in data:
            bindata.extend(bytearray(row))
        if app.kwargs["local_path"] is None:
            app.kwargs["local_path"] = path.basename(app.kwargs["path"])
        with open(app.kwargs["local_path"], "wb") as fil:
            fil.write(bindata)
        print(
            "Complete, %d bytes written to %s"
            % (len(bindata), app.kwargs["local_path"])
        )

    return dowork
