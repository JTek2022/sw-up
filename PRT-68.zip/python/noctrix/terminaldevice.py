import logging
import re
import time
import serial
import sys

from serial.tools.list_ports import comports
from threading import Thread, Event, Lock
from pick import pick
from queue import Queue
from tqdm import tqdm


class InvalidDeviceException(Exception):
    """Raised when a device is not found or is not a valid Noctrix device
    
    Args:
        port(optional): The port that was attempted to be read from
    """

    def __init__(self, port=None):
        self.port = port
        self.msg = "Please check the USB connection to the device. Try another USB cable or port"
        if port is not None:
            self.msg += f" different from {port}"
        super().__init__(self.msg)
    pass


class TerminalDevice(Thread):
    """A serial connection to a Noctrix device with a Shell.
    By default, this looks for a CP210x USB connection to a Zephyr shell
    running at 115200 baud, but could be expanded to other configurations.
    Shell commands can be wrapped around using the transact() function,
    which will execute a shell command and return the response.
    Attempts to filter out log messages or other asynchronous msgs.

    toggle the `print_log` variable to route log messages to stdout."""

    # The vid/pid of the USB device, a CP210x bridge IC
    # This is not a perfect filter, but it's the best we got
    VID = 0x10C4
    PID = 0xEA60
    MAX_RESPONSE_QUEUE_SIZE = 0  # Infinite

    # The shell prefix, used for detecting asynchronous messages
    # Note this must be a bytes object, and must include any ANSI escape bytes
    TERMSTR_BYTES = b"\x1b[1;32muart:~$ "
    LOGSTR = r"(\[?[0-9\:\.\.\,]*\]\s+\<[a-z]+\>[^\r\n]+)"
    TERMSTR = "uart:~$ "

    def __init__(self, port=None, baud=115200, timeout=0.4, logger=None):
        """Instantiate a new TerminalDevice:
        Note, call open() on this device to actually establish a connection."""

        self.logger = logger or logging.getLogger(__name__)
        self.port = port
        self.lowspeed_baud = baud
        self.highspeed_baud = 1000000
        self.highspeed = False
        self.timeout = timeout
        self.ser = None
        self.running = False
        self.print_log = False
        self.response = []
        self.expecting_response = False
        self.response_complete = Event()
        self.write_lock = Lock()
        self.raw = bytearray()
        self.response_queue = Queue(maxsize=self.MAX_RESPONSE_QUEUE_SIZE)
        self.last_write_time = None
        self.ser_id = "UNKNOWN"  # Noctrix SERID config var
        self.prog_bar = None

    def transact(
        self,
        msg,
        expecting_response=True,
        timeout=20.0,
        use_tqdm=False,
        expected_size=None,
        change_baud=None,
    ):
        """Send `msg` to the remote device, and return a list of lines in response.
        To skip waiting for a response, set `expecting_response` to False.
        A long timeout is default, since flash commands can run long"""

        ret = None
        with self.write_lock:
            self.total_bytes_read = 0

            if use_tqdm and expected_size is not None:
                self.prog_bar = tqdm(total=expected_size, leave=False)

            if expecting_response:
                self.response = []
                self.expecting_response = True
                self.raw = bytearray()

            if not isinstance(msg, bytes):
                msg = bytes(msg, "ascii")
            if not msg.endswith(b"\r\n"):
                msg += b"\r\n"

            self.ser.write(msg)

            if change_baud:
                self.ser.flush()
                time.sleep(0.25)
                self.ser.baudrate = change_baud
                self.ser.reset_input_buffer()

            if expecting_response:
                self.response_complete.clear()
                self.response_complete.wait(timeout)
                if self.prog_bar:
                    self.prog_bar.close()
                    self.prog_bar = None
                ret = self.response.copy()
                self.response = []

        """ 
            This sleep was added as a fix to prevent very fast consecutive writes from causing data loss 
            on the noctrix device side.
        """
        write_time = time.time()
        if self.last_write_time and (write_time - self.last_write_time < 0.01):
            time.sleep(0.04)

        self.last_write_time = write_time

        if ret is not None and len(ret) > 1:
            return ret[1:]

    def open(self, ignore_ports=[]):
        """Open a connection the the remote TerminalDevice,
        and create a thread to continuously read from the port.
        `port` and `baud` can be overrided from the constructor if provided"""

        if self.highspeed:
            baud = self.highspeed_baud
        else:
            baud = self.lowspeed_baud

        # Attempt autodetection
        if self.port is None:
            candidates = []
            for port in comports():
                if (type(ignore_ports) == list) and (port.device in ignore_ports):
                    continue
                if port.vid == self.VID and port.pid == self.PID:
                    candidates.append(port)

            if not candidates:
                self.logger.error("No port specified, no ports detected")
                raise InvalidDeviceException

            if len(candidates) > 1:
                # Present a picker to help us pick the right device
                opts = [
                    "%s: %s [%s]" % (x.device, x.description, x.serial_number)
                    for x in candidates
                ]
                _, idx = pick(title="Choose a device:", options=opts)
                self.port = candidates[idx].device
            else:
                self.port = candidates[0].device

        # Create a thread that will open and consume the serial port
        Thread.__init__(self, args=(self.response_queue,))
        self.daemon = True
        self.running = True

        try:
            self.ser = serial.Serial(self.port, baud, timeout=self.timeout)
        except serial.serialutil.SerialException:
            raise InvalidDeviceException(self.port)

        # Start RX thread
        self.start()

        self.detect_noctrix_and_baudrate()

        if not self.engage_highspeed(True):
            self.logger.error("Failed to engage highspeed mode")

        return True

    def detect_noctrix_and_baudrate(self):
        # Detect the device, alternating baudrate until we find it.
        for i in range(4):
            for j in range(3):
                self.expecting_response = True
                self.ser.write(b"\r\n")
                self.response_complete.wait(timeout=self.timeout)
                ret = self.transact("config get M_CALIB", timeout=0.5)
                if ret and len(ret) == 1:
                    return True
            if self.highspeed:
                self.highspeed = False
                self.ser.baudrate = self.lowspeed_baud
            else:
                self.highspeed = True
                self.ser.baudrate = self.highspeed_baud
            self.logger.warn(f"Re-trying connection at {self.ser.baudrate} baud...")

        raise InvalidDeviceException(self.port)

    def engage_highspeed(self, state):
        """Custom command, not necessarily supported:
        Attempt to increase the baudrate of the terminal device to 1MBaud.
        This depends on the remote device supporting the `baud` cmd."""

        if state:
            if self.highspeed:
                return True
            target = self.highspeed_baud
        else:
            if not self.highspeed:
                return True
            target = self.lowspeed_baud

        for _ in range(5):
            self.transact(f"baud {target}", timeout=0.5, change_baud=target)
            ret = self.transact("baud", timeout=0.5)
            if ret and ret[0] == f"{target}":
                self.highspeed = state
                return True
            time.sleep(0.1)
        return False

    def clear_response_queue(self):
        while not self.response_queue.empty():
            self.response_queue.get()

    def run(self):
        """Called internally after open() by the Thread implementation"""

        self.raw_response_queue_buffer = bytearray()
        self.raw = bytearray()
        esc = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
        while self.running:
            read_bytes = b""

            # Read as much serial data as is available
            try:
                if self.ser.in_waiting:
                    read_bytes = self.ser.read(self.ser.in_waiting)
                else:
                    read_bytes = self.ser.read(1)
                self.raw.extend(read_bytes)
                self.raw_response_queue_buffer.extend(read_bytes)
            except Exception as e:
                self.response_complete.set()
                raise e

            # Test: is this valid ASCII?
            # Doing this early in the parser to detect a bad connection
            try:
                self.raw.decode("ascii")
            except UnicodeDecodeError:
                #self.logger.warn("Invalid characters detected")
                self.raw = bytearray()
                self.raw_response_queue_buffer = bytearray()
                continue

            # Add all decoded output to queue for external tests to consume
            decoded_output = self.raw_response_queue_buffer.decode("ascii")
            self.logger.debug("RX: " + decoded_output)
            if "\r\n" in decoded_output:
                self.response_queue.put(decoded_output)
                self.raw_response_queue_buffer = bytearray()

            # Parse each line out, if it's available:
            while b"\r\n" in self.raw:
                # Snip the first raw line from the bytearray
                idx = self.raw.index(b"\r\n")
                raw_line = self.raw[:idx]
                self.raw = self.raw[idx + 2 :]

                # Escape out the ANSI escape sequence cruft:
                line = esc.sub("", raw_line.decode("ascii"))

                # Remove any log statements
                log = None
                sub = re.sub(self.LOGSTR, "", line)
                if sub != line:
                    log = line.replace(sub, "")
                    line = sub

                if log:
                    if self.print_log:
                        print(log)

                # If the line begins with a prompt, it's not a response
                if raw_line.startswith(self.TERMSTR_BYTES):
                    if self.print_log:
                        print(line)
                else:
                    if line != "":
                        # It is a response! save it
                        # Will be returned to caller when we see the next prompt
                        self.response.append(line)

                    if self.prog_bar:
                        self.prog_bar.update(len(line) + 1)

            # If waiting for a response and we see another terminal prompt
            if self.TERMSTR_BYTES in self.raw and self.expecting_response:
                # Inform the caller immediately.
                self.expecting_response = False
                self.response_complete.set()

    def close(self):
        """Close the connection, and halt the thread.
        Will block until the thread and serial port have closed."""

        if not self.engage_highspeed(False):
            self.logger.warn("Failed to disable highspeed mode")

        if self.running:
            self.running = False
            self.join(3.0)

        if self.ser:
            self.ser.close()
