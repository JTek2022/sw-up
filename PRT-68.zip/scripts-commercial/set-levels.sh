#!/bin/bash

cd ~/

# Run set-levels script
noctrix-set-levels

echo ""
echo "Press ENTER to exit..."
read -s
