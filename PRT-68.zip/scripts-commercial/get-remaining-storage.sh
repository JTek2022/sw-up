#!/bin/bash

cd ~/

# Run get-remaining-storage script
noctrix-get-remaining-storage

echo ""
echo "Press ENTER to exit..."
read -s
