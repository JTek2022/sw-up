#!/bin/bash

cd ~/

# Run imu-log-start script
noctrix-imu-log-start

echo ""
echo "Press ENTER to exit..."
read -s
