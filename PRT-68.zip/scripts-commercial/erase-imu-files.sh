#!/bin/bash

cd ~/

# Run erase-imu-files script
noctrix-erase-imu-files

echo ""
echo "Press ENTER to exit..."
read -s
