#!/bin/bash

cd ~/

# Create log_history folder if it doesn't exist
mkdir -p log_history

# Remove previous temp log output folder, recreate
rm -rf log_temp
mkdir -p log_temp

# Navigate to the temp log directory
cd log_temp

# Run dump+parse script
noctrix-dump-and-parse

# On success, noctrix-dump-and-parse will have an 
# exit code of 0
if [ $? -eq 0 ]
then
	# If successful, copy the output from the temp
	# to the history folder
	cp -R . ../log_history/
	
	# Open the log_temp folder so the user can copy
	# the files out to the necessary location
	xdg-open .
fi

echo ""
echo "Press ENTER to exit..."
read -s
