#!/bin/bash

## Remove update notifier so we dont get update popups
sudo apt remove update-notifier update-notifier-common -y
sudo apt-get purge unattended-upgrades -y

## Fetch the latest version of the package list
sudo apt update

## Install required packages
sudo apt install python3-pip tio -y
sudo apt install default-jre libreoffice-java-common -y

## Add $USER to USB permissions
sudo adduser $USER dialout

## Set the application environment
### Find config directory
if [[ ! -z "${XDG_CONFIG_HOME}" ]]; then
    CONFIG_PATH="${XDG_CONFIG_HOME}"
elif [[ ! -z "${APPDATA}" ]]; then
    CONFIG_PATH="${APPDATA}"
elif [[ ! -z "${HOME}" ]]; then
    CONFIG_PATH="${HOME}/.config"
else
    CONFIG_PATH="~/.config"
fi
CONFIG_PATH="${CONFIG_PATH}/noctrix"
mkdir -p "${CONFIG_PATH}"
### Check for environment option
if  [[ $1 = "--development" ]]; then
    ENVIRONMENT_FILE="environment.development.json"
    echo "Using development environment"
else
    ENVIRONMENT_FILE="environment.production.json"
fi
### Copy environment file
cp ~/noctrix-sw-tools/${ENVIRONMENT_FILE} "${CONFIG_PATH}/environment.json"

## Install python packages
cd ~/noctrix-sw-tools/python
mv setup-sw-tools.py setup.py
pip3 install .

## Add relevant paths to --user install so we can run from desktop shortcut

# If a backup of the original .bashrc doesn't exist, make one now
BACKUPFILE=~/.bashrc_backup
if [ ! -f "$BACKUPFILE" ]; then
	cp ~/.bashrc ~/.bashrc_backup
fi

# Copy original/backup into .bashrc before modifying
cp ~/.bashrc_backup ~/.bashrc

# tell .bashrc to source .bash_profile for terminal windows
echo "" >> ~/.bashrc
echo "source ~/.bash_profile" >> ~/.bashrc

# If a backup of the original .bash_profile doesn't exist, make one now
BACKUPFILE_PROF=~/.bash_profile_backup
if [ ! -f "$BACKUPFILE_PROF" ]; then
    cp ~/.bash_profile ~/.bash_profile_backup
fi

# Copy original/backup into .profile before modifying
cp ~/.bash_profile_backup ~/.bash_profile

# Add python user install path to system path
echo "" >> ~/.bash_profile
echo "export PATH=\"\$PATH:\$HOME/.local/bin\"" >> ~/.bash_profile

## Create Desktop Shortcuts
SCRIPTS="
    noctrix-config-log-dump
    noctrix-fw-config
    noctrix-log-dump
    noctrix-log-dump-analyze
    noctrix-imu-config
    noctrix-imu-dump
    noctrix-imu-log-start
    noctrix-imu-log-stop
    noctrix-imu-log-test
    noctrix-get-remaining-storage
    noctrix-erase-imu-files
    noctrix-set-levels
    noctrix-log-dump-upload
"
for i in ${SCRIPTS}; do
    # Copy desktop file
    cp ~/noctrix-sw-tools/scripts-commercial/$i.desktop ~/Desktop/
    # Make launchable
    sudo desktop-file-install --mode=0755 ~/Desktop/$i.desktop
    # Make executable
    gio set ~/Desktop/$i.desktop metadata::trusted true
    chmod +x ~/Desktop/$i.desktop
done

## We must reboot to finish setup
echo ""
echo "------------------------------------------------------"
echo ""
echo "Initialization setup requires rebooting."
echo "Press ENTER to reboot now..."
read -s
sudo reboot
