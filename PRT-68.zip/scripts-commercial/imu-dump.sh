#!/bin/bash

cd ~/

# Create imu_history folder if it doesn't exist
mkdir -p imu_history

# Remove previous temp imu output folder, recreate
rm -rf imu_temp
mkdir -p imu_temp

# Navigate to the temp imu directory
cd imu_temp

# Run imu dump script
noctrix-imu-dump-multi

# On success, noctrix-imu-dump-multi will have an
# exit code of 0
if [ $? -eq 0 ]
then
	# Open the imu_temp folder so the user can copy
	# the files out to the necessary location
	xdg-open .
fi

# Regardless of success, copy the output from the temp
# to the history folder. This way we definitely won't lose
# any progress by re-running the script as imu-dump can generate
# multiple files
cp -R . ../imu_history/

echo ""
echo "Press ENTER to exit..."
read -s
