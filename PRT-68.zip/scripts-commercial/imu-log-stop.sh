#!/bin/bash

cd ~/

# Run imu-log-stop script
noctrix-imu-log-stop

echo ""
echo "Press ENTER to exit..."
read -s
