#!/bin/bash

cd ~/

# Run imu-log-test script
noctrix-imu-log-test

echo ""
echo "Press ENTER to exit..."
read -s
